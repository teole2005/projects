public class Attack {
    private int defnumber;
    public Attack(int atknumber, int defnumber, String atkertype, String defertype, int skill) {
        this.defnumber = defnumber; // Initialize defnumber
        try {
            if (skill == 1) {
                // Attack type and defense type handling
                switch (atkertype) {
                    case "Grass":
                        switch (defertype) {
                            case "Electric":
                                this.defnumber = goodDamage(defnumber, atknumber);
                                break;
                            case "Fire":
                                this.defnumber = weakDamage(defnumber, atknumber);
                                break;
                            case "Water":
                                this.defnumber = goodDamage(defnumber, atknumber); // Assuming this should apply goodDamage
                                break;
                            case "Ghost":
                                this.defnumber = normalDamage(defnumber, atknumber);
                                break;
                            case "Grass":
                                this.defnumber = noDamage(defnumber, atknumber);
                                break;
                        }
                        break;

                    case "Fire":
                        switch (defertype) {
                            case "Electric":
                                this.defnumber = goodDamage(defnumber, atknumber);
                                break;
                            case "Fire":
                                this.defnumber = noDamage(defnumber, atknumber);
                                break;
                            case "Grass":
                                this.defnumber = goodDamage(defnumber, atknumber);
                                break;
                            case "Water":
                                this.defnumber = weakDamage(defnumber, atknumber);
                                break;
                            case "Ghost":
                                this.defnumber = normalDamage(defnumber, atknumber);
                                break;
                        }
                        break;

                    case "Electric":
                        switch (defertype) {
                            case "Electric":
                                this.defnumber = noDamage(defnumber, atknumber);
                                break;
                            case "Fire":
                                this.defnumber = normalDamage(defnumber, atknumber);
                                break;
                            case "Grass":
                                this.defnumber = weakDamage(defnumber, atknumber);
                                break;
                            case "Water":
                                this.defnumber = goodDamage(defnumber, atknumber);
                                break;
                            case "Ghost":
                                this.defnumber = weakDamage(defnumber, atknumber);
                                break;
                        }
                        break;

                    case "Water":
                        switch (defertype) {
                            case "Electric":
                                this.defnumber = goodDamage(defnumber, atknumber); // Assuming this should apply goodDamage
                                break;
                            case "Fire":
                                this.defnumber = goodDamage(defnumber, atknumber);
                                break;
                            case "Grass":
                                this.defnumber = weakDamage(defnumber, atknumber);
                                break;
                            case "Water":
                                this.defnumber = goodDamage(defnumber, atknumber);
                                break;
                            case "Ghost":
                                this.defnumber = weakDamage(defnumber, atknumber);
                                break;
                        }
                        break;

                    case "Ghost":
                        switch (defertype) {
                            case "Electric":
                                this.defnumber = noDamage(defnumber, atknumber);
                                break;
                            case "Fire":
                                this.defnumber = normalDamage(defnumber, atknumber);
                                break;
                            case "Grass":
                                this.defnumber = weakDamage(defnumber, atknumber);
                                break;
                            case "Water":
                                this.defnumber = goodDamage(defnumber, atknumber);
                                break;
                            case "Ghost":
                                this.defnumber = weakDamage(defnumber, atknumber);
                                break;
                        }
                        break;

                    default:
                        throw new IllegalArgumentException("Invalid attack type: " + atkertype);
                }
            } else if (skill == 2) {
                this.defnumber = normalDamage(defnumber, atknumber);
            } else {
                throw new IllegalArgumentException("Invalid skill type: " + skill);
            }
        } catch (Exception e) {
            System.out.println("Invalid choice or error: " + e.getMessage());
        }
    }

    // Damage calculation methods
    private int goodDamage(int defnumber, int atk) {
        this.defnumber = defnumber - (atk * 50 / 100);
        System.out.format("%10s %15s","Good damage","-"+(atk * 50 / 100)+" damage");
        return this.defnumber;
    }

    private int normalDamage(int defnumber, int atk) {
        
        this.defnumber = defnumber - (atk * 20 / 100);
        System.out.format("%10s %15s","normal damage","-"+(atk * 20 / 100)+" damage");
        return this.defnumber;
    }

    private int noDamage(int defnumber, int atk) {
        System.out.format("%10s %15s","no damage","-0 damage ");
        return defnumber; // No change to def
    }

    private int weakDamage(int defnumber, int atk) {
       
        this.defnumber = defnumber - (atk * 10 / 100);
        System.out.format("%10s %15s","weak damage","-"+(atk * 10 / 100)+" damage ");
        return this.defnumber;
    }

    public int getDefNumber() {
        return defnumber;
    }
}
