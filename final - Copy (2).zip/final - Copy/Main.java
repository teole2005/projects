import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("What's your name? ");
        String playerName = scanner.nextLine();
        System.out.println("Welcome " + playerName);

        while (true) {
            displayMenu();

            try {
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                    System.out.println("Starting the game...");
                        new Game(playerName);
                        
                        break;
                    case 2:
                        new Player(playerName).DisplayTopFive(playerName);
                        break;
                    case 3:
                        // Placeholder for listing available Pokémon
                        System.out.println("Displaying available Pokémon in your basement...");
                      
                        ArrayList<String> availablePokemon = new Player(playerName).getAvailablePoke();
                        System.out.println("In your basement you have: " + availablePokemon);
                        break;
                    case 4:
                        System.out.println("Exiting the game. Goodbye!");
                        scanner.close();
                        return; // Exit the program
                    default:
                        System.out.println("Invalid number. Please choose a valid option.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                scanner.next(); // Clear the invalid input
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nMenu:");
        System.out.println("(1) Start the game");
        System.out.println("(2) Display top 5 points");
        System.out.println("(3) See available Pokémon in your basement");
        System.out.println("(4) Exit");
    }
}

         
