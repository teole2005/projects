import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
    import java.util.Scanner;
    public class Game {
        public Game(String playerName) {
            String playername=playerName;
            Player p=new Player(playername);

            Scanner scanner= new Scanner(System.in);
            ArrayList<PokechoFinal> list = new ArrayList<>();
            ArrayList<PokechoFinal> pokeparty = new ArrayList<>();
            ArrayList<PokechoFinal> pokedetail1 = new ArrayList<>();
            // Thêm phần tử vào ArrayList
            list.add(new PokechoFinal("Pikachu", "Electric", 555, 400,1));
            list.add(new PokechoFinal("Charmander", "Fire", 520, 450,2));
            list.add(new PokechoFinal("Bulbasaur", "Grass", 490, 495,3));
            list.add(new PokechoFinal("Squirtle", "Water", 300, 505,3));
            list.add(new PokechoFinal("Gengar", "Ghost", 590, 450,2));
            Random random = new Random();
            ArrayList<Integer> pokeoptions = new ArrayList<Integer>();
            ArrayList<String> set = new ArrayList<String>();
         
         ArrayList<String> j= p.getAvailablePoke();
         System.out.println(j.size());
         String ifhavepoke="no";
           if (p.getHavePokeInBasementOrNot() =="yes") { if (j.size()>=2) {
        
            System.out.println("pick 2 pokemon for ur party");
            ArrayList hh=j;
            System.out.format("%-15s%-15s%-15s%-15s%-15s%n", "Name", "Type", "Attack", "Defense", "Rarity");
            for(int idk=0;idk<j.size();idk++){
       
            for(int z=0;z<list.size();z++){
if (hh.get(idk).equals(list.get(z).getName())) {

     
   System.out.format("%-15s%-15s%-15s%-15s%-15s%n", list.get(z).getName(),list.get(z).getType(),list.get(z).getAttack(),list.get(z).getDefense(),list.get(z).getRarity()); 
   pokedetail1.add(new PokechoFinal(list.get(z).getName(),list.get(z).getType(),list.get(z).getAttack(),list.get(z).getDefense(),list.get(z).getRarity()));
    break;
}
            }}
            
          while (pokeparty.size() < 2) {
    try {
        System.out.println("Please choose a pokemon by entering the number next to it:");
        for (int i = 0; i < pokedetail1.size(); i++) {
            System.out.println((i + 1) + ". " + pokedetail1.get(i).getName());
        }

        int pokechoice = scanner.nextInt() - 1;
        if (pokechoice+1>pokedetail1.size()) {
            System.out.println("Invalid number. Please choose a number between 1 and " + pokedetail1.size());

        }
        if (pokechoice >= 0 && pokechoice < pokedetail1.size()) {
            System.out.println("You chose " + pokedetail1.get(pokechoice).getName());
            pokeparty.add(new PokechoFinal(
                pokedetail1.get(pokechoice).getName(),
                pokedetail1.get(pokechoice).getType(),
                pokedetail1.get(pokechoice).getAttack(),
                pokedetail1.get(pokechoice).getDefense(),
                pokedetail1.get(pokechoice).getRarity()
            ));
            pokedetail1.remove(pokechoice);
        }
      
    } catch (InputMismatchException e) {
        System.out.println("Invalid input. Please enter a number.");
        scanner.next(); // Clear the invalid input
    } 
    catch (Exception e) {
        System.out.println("An error occurred: " + e.getMessage());
    }
}
 ifhavepoke="yes";
           }
           }
           if (p.getHavePokeInBasementOrNot()=="no"|| ifhavepoke=="no") {
            System.out.println("u dont have enough pokemon in ur basement, catch below pokemon");
            System.out.format("%-15s%-15s%-15s%-15s%-15s%n", "Name", "Type", "Attack", "Defense", "Rarity");
            for ( int i=0;i<3;i++) {
                int x = random.nextInt(list.size());
                pokeoptions.add(x);
                PokechoFinal pokecho = list.get(x);
             
                
System.out.format("%-15s%-15s%-15d%-15d%-15s%n", 
    pokecho.getName(), 
    pokecho.getType(), 
    pokecho.getAttack(), 
    pokecho.getDefense(), 
    pokecho.getRarity()
);
                set.add(pokecho.getName());
        } System.out.println("there 3 pokemon, pick the one u want (1, 2, 3)");
        for (int loop3 = 1; loop3 > 0; loop3++) {
            try {
                if (pokeparty.size() < 2) {
                    System.out.println(set);
                    
                    try {
                        int pokechoice = scanner.nextInt() - 1;
                        
                        if (pokechoice >= 0 && pokechoice < pokeoptions.size()) {
                            System.out.println("You choose " + list.get(pokeoptions.get(pokechoice)).getName());
                            pokeparty.add(new PokechoFinal(
                                list.get(pokeoptions.get(pokechoice)).getName(),
                                list.get(pokeoptions.get(pokechoice)).getType(),
                                list.get(pokeoptions.get(pokechoice)).getAttack(),
                                list.get(pokeoptions.get(pokechoice)).getDefense(),
                                list.get(pokeoptions.get(pokechoice)).getRarity()
                            ));
                            set.remove(pokechoice);      
                            pokeoptions.remove(pokechoice);
                        } else {
                            System.out.println("Invalid number. Please choose a number between 1 and " + pokeoptions.size());
                        }
                        
                    } catch (InputMismatchException e) {
                        System.out.println("Please enter a correct input (number).");
                        scanner.next(); // Clear the invalid input
                    } catch (IndexOutOfBoundsException e) {
                        System.out.println("Invalid number. Please choose a number between 1 and " + pokeoptions.size());
                    }
                }
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }
        }
        
        }

    int enmypoke=random.nextInt(list.size());
        String b=list.get(enmypoke).getName();
        String b1=list.get(enmypoke).getType();
        int b2=list.get(enmypoke).getAttack();
        int b3=list.get(enmypoke).getDefense();
        int b4=list.get(enmypoke).getRarity();
        for (int loop3 = 1; loop3 > 0; loop3++) {
        try {
        System.out.println("would u go to battle (1)yes (2)return to menu");
        Scanner scanner2= new Scanner(System.in);
        int k=scanner2.nextInt();
        if (k==2) {
            new Main(); 
        }
        if (k==1) {
            System.out.println("ur enemy is");
            System.out.format("%-15s%-15s%-15s%-15s%-15s%n", "Name", "Type", "Attack", "Defense", "Rarity");
            System.out.format("%-15s%-15s%-15d%-15d%-15s%n",b,b1,b2,b3,b4);
            System.out.println("go to battle");
            System.out.println("choose the poke");
            System.out.println("(1) "+pokeparty.get(0).getName() +" or (2) "+ pokeparty.get(1).getName());
            String a;
        String a1;
        int a2;
        int a3;
        int a4;
        int playerpoke;

            while (true) {
                try {
                    System.out.print("Enter your Pokémon choice: ");
                    int pokechoice = scanner.nextInt();
                    playerpoke = pokechoice - 1;
                    
                    if (playerpoke < 0 || playerpoke >= pokeparty.size()) {
                        throw new IndexOutOfBoundsException("Invalid choice. Please choose a valid Pokémon.");
                    }
    
                    PokechoFinal chosenPokemon = pokeparty.get(playerpoke);
                    a  = chosenPokemon.getName();
                    a1 = chosenPokemon.getType();
                    a2 = chosenPokemon.getAttack();
                    a3 = chosenPokemon.getDefense();
                    a4 = chosenPokemon.getRarity();    
                    break; 
    
                } catch (IndexOutOfBoundsException e) {
                    System.out.println(e.getMessage());
                } catch (Exception e) {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next(); // Clear the invalid input
                }
            }
            System.out.println("You have chosen " + a);
            Battle z = new Battle(a1,a2,a3,b1,b2,b3);

        if (z.getBattleResult()=="won") {
            
        
            p.CalculatePoints(90, "won");
for(int loop4=1;loop4>0;loop4++){
        try {
            System.out.println("would u like to catch "+b+"? (1) yes (2) no");
        Scanner scanner3= new Scanner(System.in);
        int userName=scanner3.nextInt();
            if (userName==1) {
                CatchPoke catchresult=new CatchPoke(b4);
                if (catchresult.catchresult=="success") {
                   System.out.println("u got "+b);
                   p.SavePlayerPoke(playername,b);
                }
                if (catchresult.catchresult=="fail") {
               
                }
                break;
            }
            if (userName==2) {
               break;
            }
            else{System.out.println("please enter correct input");}
        } 
        catch (InputMismatchException e) {
            System.out.println("please enter correct input");
        }
    }  
    
            int enmypokend=random.nextInt(list.size());
                String bnd=list.get(enmypokend).getName();
                String b1nd=list.get(enmypokend).getType();
                int b2nd=list.get(enmypokend).getAttack();
                int b3nd=list.get(enmypokend).getDefense();
                int b4nd=list.get(enmypokend).getRarity();
                System.out.println("a new wild pokemon ");
                System.out.format("%-15s%-15s%-15s%-15s%-15s%n", "Name", "Type", "Attack", "Defense", "Rarity");
                System.out.format("%-15s%-15s%-15d%-15d%-15s%n",bnd,b1nd,b2nd,b3nd,b4nd);
               Battle z1=new Battle(a1,a2,z.getPlayerHp(),b1nd,b2nd,b3nd);
              
                if (z1.getBattleResult()=="won") {
                     p.CalculatePoints(z1.getPlayerHp(), "won");
                    try {
                    System.out.println("would u like to catch "+bnd+" ? (1) yes (2) no");
                    Scanner scanner6= new Scanner(System.in);
                    int userName1=scanner6.nextInt();
                    if (userName1==1) {
                        CatchPoke catchresult=new CatchPoke(b4nd);
                        if (catchresult.catchresult=="success") {
                            System.out.println("u got "+bnd);
                            p.SavePlayerPoke(playername, bnd);
                        }
                        if (catchresult.catchresult=="fail") {
                            System.out.println("pathetic");
                        }
                        break;
                        }
                        if (userName1==2) {
                            System.out.println("ok");
                            break;
                        }
                        else{
                            System.out.println("invail number");
                        } } catch (InputMismatchException e) {
                            System.out.println("please enter correct input");
                        }
                        }
                 if (z1.getBattleResult()=="fail"){
                            pokeparty.remove(playerpoke);
                            p.CalculatePoints(z1.getAIHp(), "fail");
                            System.out.println("ur poke now is ");
                            System.out.format("%-15s%-15s%-15s%-15s%-15s%n", "Name", "Type", "Attack", "Defense", "Rarity");
                            System.out.format("%-15s%-15s%-15d%-15d%-15s%n",pokeparty.get(0).getName(),pokeparty.get(0).getType(),pokeparty.get(0).getAttack(),pokeparty.get(0).getDefense(),pokeparty.get(0).getRarity());
                            Battle z2=new Battle(pokeparty.get(0).getType(),pokeparty.get(0).getAttack(),pokeparty.get(0).getDefense(),b1nd,b2nd,z1.getAIHp());
                           if (z2.getBattleResult()=="won") {
                            for(int loop5=1;loop5>0;loop5++){
                            try {
                            p.CalculatePoints(z2.getPlayerHp(), "won");
                            System.out.println("would u like to catch "+bnd+"? (1) yes (2) no");
                            Scanner scanner8= new Scanner(System.in);
                            int userName2=scanner8.nextInt();
                            if (userName2==1) {
                                CatchPoke catchresult=new CatchPoke(b4nd);
                                if (catchresult.catchresult=="success") {
                                    System.out.println("u got "+bnd);
                                    p.SavePlayerPoke(playername, bnd);
                                }
                                if (catchresult.catchresult=="fail") {
                                    System.out.println("pathetic");
                                }
                                break;
                                }
                                if (userName2==2) {
                                    System.out.println("ok");
                                    break;
                                }
                                else{
                                    System.out.println("invail number");
                                } } catch (InputMismatchException e) {
                                    System.out.println("please enter correct input");
                                }
                            }
                           }
                           if (z2.getBattleResult()=="fail") {                    
                           }
                           }
           } 
           if (z.getBattleResult()=="fail"){
            pokeparty.remove(playerpoke);
            System.out.println("ur pokemon now");
            System.out.format("%-15s%-15s%-15s%-15s%-15s%n", "Name", "Type", "Attack", "Defense", "Rarity");
            System.out.format("%-15s%-15s%-15d%-15d%-15s%n",pokeparty.get(0).getName(),pokeparty.get(0).getType(),pokeparty.get(0).getAttack(),pokeparty.get(0).getDefense(),pokeparty.get(0).getRarity());
            p.CalculatePoints( z.getPlayerHp(), "fail");
            Battle z3=new Battle(pokeparty.get(0).getType(),pokeparty.get(0).getAttack(),pokeparty.get(0).getDefense(),b1,b2,z.getAIHp());
           if (z3.getBattleResult()=="won") {
            p.CalculatePoints(z3.getPlayerHp(), "won");
            for(int loop6=1;loop6>0;loop6++){
          
            try{
            System.out.println("would u like to catch "+b+" ? (1) yes (2) no");
            Scanner scanner6= new Scanner(System.in);
            int userName1=scanner6.nextInt();
            if (userName1==1) {
                CatchPoke catchresult=new CatchPoke(b4);
                if (catchresult.catchresult=="success") {
                    System.out.println("u got "+b);
                    p.SavePlayerPoke(playername, b);
                }
                if (catchresult.catchresult=="fail") {
                    System.out.println("pathetic");
                }
                break;
                }
            if (userName1==2) {
                    System.out.println("ok");
                    break;
                }
            else{
                System.out.println("invail number");
                }
            } catch (InputMismatchException e) {
                    System.out.println("please enter correct input");
                }
            }
            int enmypokend=random.nextInt(list.size());
                String bnd=list.get(enmypokend).getName();
                String b1nd=list.get(enmypokend).getType();
                int b2nd=list.get(enmypokend).getAttack();
                int b3nd=list.get(enmypokend).getDefense();
                int b4nd=list.get(enmypokend).getRarity();
                System.out.println("a new wild pokemon ");
                System.out.format("%-15s%-15s%-15s%-15s%-15s%n", "Name", "Type", "Attack", "Defense", "Rarity");
                System.out.format("%-15s%-15s%-15d%-15d%-15s%n",bnd,b1nd,b2nd,b3nd,b4nd);
                Battle z4=new Battle(a1,a2,z.getPlayerHp(),b1nd,b2nd,b3nd);
              
                if (z4.getBattleResult()=="won") {
                    p.CalculatePoints(z4.getPlayerHp(), "won");
                    for(int loop6=1;loop6>0;loop6++){
                    try{
                    System.out.println("would u like to catch "+bnd+" ? (1) yes (2) no");
                    Scanner scanner7= new Scanner(System.in);
                    int userName2=scanner7.nextInt();
                    if (userName2==1) {
                        CatchPoke catchresult=new CatchPoke(b4nd);
                        if (catchresult.catchresult=="success") {
                            System.out.println("u got "+bnd);
                            p.SavePlayerPoke(playername, bnd);
                        }
                        if (catchresult.catchresult=="fail") {
                            System.out.println("pathetic");
                            break;
                        }
                        }
                        if (userName2==2) {
                            System.out.println("ok");
                            break;
                        }
                        else{
                            System.out.println("invail number");
                        } } catch (InputMismatchException e) {
                            System.out.println("please enter correct input");
                        }
                    }
                }
                 if (z4.getBattleResult()=="fail"){
                    p.CalculatePoints(z4.getPlayerHp(), "fail");
                    break;
                 }
                }
           if (z3.getBattleResult()=="fail") {
            p.CalculatePoints( z.getPlayerHp(), "fail");
           }
           }
           break;
        }
        else{ System.out.println("invail number");}
       
    } 
    catch (InputMismatchException e) {
        System.out.println("please enter correct input");
    }
}
        for (int loop=1;loop>0;loop++){
        System.out.println("wanna see ur point: (1) nah (2) ok");
        try {
            Scanner scanner9=new Scanner(System.in);
        int w=scanner9.nextInt();
        if (w==1) {
            new Main();
            break;
        }
        if (w==2) {
            p.DisplayTopFive(playername);
            break;
        }
        else{
                System.out.println("invail number");
            }
        } catch (InputMismatchException e) {
            System.out.println("please enter correct input");
        }
    }
        new Main();  
        }

    }
    
    


    
    

