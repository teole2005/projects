import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Random;

public class Battle {

    private String battleresult;
    private int playerdef;
    private int AIdef;
    private Scanner scanner = new Scanner(System.in);

    public Battle(String playerpoketype, int playerpokeatk, int playerpokedef, String AIpoketype, int AIpokeatk, int AIpokedef) {
        String playertype = playerpoketype;
        int playeratk = playerpokeatk;
        this.playerdef = playerpokedef;
        String AItype = AIpoketype;
        int AIatk = AIpokeatk;
         this.AIdef = AIpokedef;
     
        Random random = new Random();
        int whofirst = random.nextInt(10) + 2;
        for (int i = whofirst; i > 0; i++) {
            if (i % 2 == 1) {
                playerturn(playeratk, AIdef, playertype, AItype);
                System.out.println("");
                if (AIdef > 0) {
                    System.out.println("Enemy HP: " + AIdef + " left");
                } else {
                    System.out.println("Enemy HP: 0");
                    System.out.println("You won");
                    battleresult = "won";
                    break;
                }
            }
            if (i % 2 == 0) {
                enemyturn(AIatk, playerdef, AItype, playertype);
                System.out.println("");
                if (playerdef > 0) {
                    System.out.println("Your HP: " + playerdef + " left");
                } else {
                    System.out.println("Your HP: 0");
                    System.out.println("You lose");
                    battleresult = "fail";
                    break;
                }
            }
        }
    }

    public void enemyturn(int AIatk, int playerdef, String AItype, String playertype) {
        System.out.println("Enemy turn");
        Random random = new Random();
        int enemyskill = random.nextInt(2) + 1;
        Attack attack = new Attack(AIatk, playerdef, AItype, playertype, enemyskill);
        playerdef = attack.getDefNumber();
        setPlayerHp(playerdef);
    }

    public void playerturn(int playeratk, int AIdef, String playertype, String AItype) {
        System.out.println("Choose your skill (enter 1 (element skill) or 2 (physical skill)):");
        int playerskill = 0;
        boolean validInput = false;
        while (!validInput) {
            try {
                playerskill = scanner.nextInt();
                if (playerskill == 1 || playerskill == 2) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter 1 or 2.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number (1 or 2).");
                scanner.next(); // Clear the invalid input
            }
        }
        Attack attack = new Attack(playeratk, AIdef, playertype, AItype, playerskill);
        AIdef = attack.getDefNumber();
        setAIHp(AIdef);
    }

    public String getBattleResult() {
        return battleresult;
    }

    // Getters and setters for demonstration
    public int getPlayerHp() {
        return playerdef;
    }

    public void setPlayerHp(int playerhp) {
        playerdef = playerhp;
    }

    public int getAIHp() {
        return AIdef;
    }

    public void setAIHp(int AIhp) {
        this.AIdef = AIhp;
    }
 
}
