

public class PokechoFinal {
    private String name;
    private String type;
    private int attack;
    private int defense;
    private int rarity;
    // Constructor
    public PokechoFinal(String name, String type, int attack, int defense, int rarity) {
        this.name = name;
        this.type = type;
        this.attack = attack;
        this.defense = defense;
        this.rarity=rarity;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public int getAttack() {
        return attack;
    }

    public int getDefense() {
        return defense;
    }
    public int getRarity() {
        return rarity;
    }


}

