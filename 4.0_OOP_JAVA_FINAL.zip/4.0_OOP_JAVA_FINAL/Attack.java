import java.util.Random;

public class Attack {
    private int defnumber;

    public Attack(int atknumber, int defnumber, String atkertype, String defertype, int skill) {
        String boldStart = "\033[1m";
        String reset = "\033[0m";
        this.defnumber = defnumber; // Initialize defnumber
        try {
            switch (skill) {
                case 1: // Element Skill
                    applyElementSkill(atkertype, defertype, atknumber);
                    break;
                case 2: // Physical Skill
                    this.defnumber = normalDamage(defnumber, atknumber);
                    break;
                case 3: // Z-Move
                    this.defnumber = zMoveDamage(defnumber, atknumber);
                    break;
                case 4: // Double Rush
                    this.defnumber = doubleRushDamage(defnumber, atknumber);
                    break;
                case 5: // Rush Combo
                    this.defnumber = rushComboDamage(defnumber, atknumber);
                    break;
                case 6: // Defense
                    applyDefense();
                    break;
                default:
                    throw new IllegalArgumentException("Invalid skill type: " + skill + '\n');
            }
        } catch (Exception e) {
            System.out.println("Invalid choice or error: " + e.getMessage() + '\n');
        }
    }

    private void applyElementSkill(String atkertype, String defertype, int atknumber) {
        switch (atkertype) {
            case "Grass":
                switch (defertype) {
                    case "Electric":
                    case "Water":
                        this.defnumber = goodDamage(defnumber, atknumber);
                        break;
                    case "Fire":
                        this.defnumber = weakDamage(defnumber, atknumber);
                        break;
                    case "Ghost":
                        this.defnumber = normalDamage(defnumber, atknumber);
                        break;
                    case "Grass":
                        this.defnumber = noDamage(defnumber, atknumber);
                        break;
                }
                break;

            case "Fire":
                switch (defertype) {
                    case "Electric":
                    case "Grass":
                        this.defnumber = goodDamage(defnumber, atknumber);
                        break;
                    case "Water":
                        this.defnumber = weakDamage(defnumber, atknumber);
                        break;
                    case "Ghost":
                        this.defnumber = normalDamage(defnumber, atknumber);
                        break;
                    case "Fire":
                        this.defnumber = noDamage(defnumber, atknumber);
                        break;
                }
                break;

            case "Electric":
                switch (defertype) {
                    case "Water":
                        this.defnumber = goodDamage(defnumber, atknumber);
                        break;
                    case "Ghost":
                    case "Grass":
                        this.defnumber = weakDamage(defnumber, atknumber);
                        break;
                    case "Fire":
                        this.defnumber = normalDamage(defnumber, atknumber);
                        break;
                    case "Electric":
                        this.defnumber = noDamage(defnumber, atknumber);
                        break;
                }
                break;

            case "Water":
                switch (defertype) {
                    case "Electric":
                        this.defnumber = goodDamage(defnumber, atknumber);
                        break;
                    case "Fire":
                    case "Water":
                        this.defnumber = goodDamage(defnumber, atknumber);
                        break;
                    case "Grass":
                        this.defnumber = weakDamage(defnumber, atknumber);
                        break;
                    case "Ghost":
                        this.defnumber = normalDamage(defnumber, atknumber);
                        break;
                }
                break;

            case "Ghost":
                switch (defertype) {
                    case "Electric":
                        this.defnumber = noDamage(defnumber, atknumber);
                        break;
                    case "Fire":
                        this.defnumber = normalDamage(defnumber, atknumber);
                        break;
                    case "Grass":
                    case "Water":
                        this.defnumber = weakDamage(defnumber, atknumber);
                        break;
                    case "Ghost":
                        this.defnumber = normalDamage(defnumber, atknumber);
                        break;
                }
                break;

            default:
                throw new IllegalArgumentException("Invalid attack type: " + atkertype + '\n');
        }
    }

    // New skill damage calculations
    private int zMoveDamage(int defnumber, int atk) {
        this.defnumber = defnumber - (atk * 25 / 100);
        System.out.format("%10s %15s", "Z-Move", "-" + (atk * 25 / 100) + " damage");
        return this.defnumber;
    }

    private int doubleRushDamage(int defnumber, int atk) {
        this.defnumber = defnumber - (atk * 40 / 100);
        System.out.format("%10s %15s", "Double Rush", "-" + (atk * 40 / 100) + " damage");
        return this.defnumber;
    }

    private int rushComboDamage(int defnumber, int atk) {
        this.defnumber = defnumber - (atk * 35 / 100);
        System.out.format("%10s %15s", "Rush Combo", "-" + (atk * 35 / 100) + " damage");
        return this.defnumber;
    }

    // Damage calculation methods for element skills
    private int goodDamage(int defnumber, int atk) {
        this.defnumber = defnumber - (atk * 20 / 100);
        System.out.format("%10s %15s", "Good Damage", "-" + (atk * 20 / 100) + " damage");
        return this.defnumber;
    }

    private int normalDamage(int defnumber, int atk) {
        this.defnumber = defnumber - (atk * 10 / 100);
        System.out.format("%10s %15s", "Normal Damage", "-" + (atk * 10 / 100) + " damage");
        return this.defnumber;
    }

    private int noDamage(int defnumber, int atk) {
        System.out.format("%10s %15s", "No Damage", "-0 damage ");
        return defnumber; // No change to def
    }

    private int weakDamage(int defnumber, int atk) {
        this.defnumber = defnumber - (atk * 10 / 100);
        System.out.format("%10s %15s", "Weak Damage", "-" + (atk * 10 / 100) + " damage ");
        return this.defnumber;
    }

    // Defense mechanism
    private void applyDefense() {
        Random random = new Random();
        if (random.nextInt(100) < 40) { // 48% chance of successful defense
            System.out.println("Defense successful! No damage taken.");
            // No change to defnumber
        } else {
            System.out.println("Defense failed! Full damage taken.");
            // This method should not reduce defnumber further
        }
    }

    public int getDefNumber() {
        return defnumber;
    }
}
