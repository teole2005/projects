import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Battle {
    String boldStart = "\033[1m";
    String reset = "\033[0m";

    private String battleresult;
    private int playerdef;
    private int AIdef;
    private Scanner scanner = new Scanner(System.in);

    public Battle(PokechoFinal player, int playerdef, PokechoFinal AI, int AIdef) {
        String playertype = player.getType();
        int playeratk = player.getAttack();
        this.playerdef = playerdef;
        String AItype = AI.getType();
        int AIatk = AI.getAttack();
        this.AIdef = AIdef;

        Random random = new Random();
        int whofirst = random.nextInt(10) + 2;
        for (int i = whofirst; i > 0; i++) {
            if (i % 2 == 1) {
                playerturn(playeratk, AIdef, playertype, AItype);
                System.out.println("");
                if (getAIHp() > 0) {
                    System.out.println(boldStart + "ENEMY HP LEFT:  " + getAIHp() + "HP" + reset + '\n');
                } else {
                    System.out.println('\n' + "ENEMY HP = 0");
                    System.out.println(boldStart + "YOU WON !" + reset + '\n');
                    battleresult = "won";
                    break;
                }
            }
            if (i % 2 == 0) {
                enemyturn(AIatk, playerdef, AItype, playertype);
                System.out.println("");
                if (getPlayerHp() > 0) {
                    System.out.println(boldStart + "YOUR HP LEFT:  " + getPlayerHp() + "HP" + reset + '\n');
                } else {
                    System.out.println('\n' + "YOUR HP = 0");
                    System.out.println(boldStart + "NOOO! YOU HAVE LOST THE BATTLE!" + reset + '\n');
                    battleresult = "fail";
                    break;
                }
            }
        }
    }

    public void enemyturn(int AIatk, int playerdef, String AItype, String playertype) {
        System.out.println('\n' + "****** Enemy Turn ******" + '\n');
        Random random = new Random();
        int action = random.nextInt(2); // 0 for attack, 1 for defense

        if (action == 0) {
            int enemyskill = random.nextInt(5) + 1; // Range 1-5 for different skills
            Attack attack = new Attack(AIatk, getPlayerHp(), AItype, playertype, enemyskill);
            playerdef = attack.getDefNumber();
        } else {
            if (random.nextInt(100) < 48) { // 48% chance of successful defense
                System.out.println("Enemy successfully defended!");
            } else {
                System.out.println("Enemy failed to defend! Enemy attacks.");
                int enemyskill = random.nextInt(5) + 1; // Range 1-5 for different skills
                Attack attack = new Attack(AIatk, getPlayerHp(), AItype, playertype, enemyskill);
                playerdef = attack.getDefNumber();
            }
        }
        setPlayerHp(playerdef);
    }

    public void playerturn(int playeratk, int AIdef, String playertype, String AItype) {
        System.out.println("Choose your action: [Enter 1. Element Skill, 2. Physical Skill, 3. Z-Move, 4. Double Rush, 5. Rush Combo, 6. Defend]");
        int playerskill = 0;
        boolean validInput = false;
        while (!validInput) {
            try {
                playerskill = scanner.nextInt();
                if (playerskill >= 1 && playerskill <= 6) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter a number between 1 and 6." + '\n');
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number (1-6)." + '\n');
                scanner.next(); // Clear the invalid input
            }
        }

        if (playerskill == 6) {
            if (new Random().nextInt(100) < 48) { // 48% chance of successful defense
                System.out.println("You successfully defended!");
            } else {
                System.out.println("Defense failed! Enemy attacks.");
                int enemyskill = new Random().nextInt(5) + 1; // Range 1-5 for different skills
                Attack attack = new Attack(playeratk, getAIHp(), playertype, AItype, enemyskill);
                AIdef = attack.getDefNumber();
            }
        } else {
            Attack attack = new Attack(playeratk, getAIHp(), playertype, AItype, playerskill);
            AIdef = attack.getDefNumber();
        }
        setAIHp(AIdef);
    }

    public String getBattleResult() {
        return battleresult;
    }

    // Getters and setters for demonstration
    public int getPlayerHp() {
        return playerdef;
    }

    public void setPlayerHp(int playerhp) {
        this.playerdef = playerhp;
    }

    public int getAIHp() {
        return AIdef;
    }

    public void setAIHp(int AIhp) {
        this.AIdef = AIhp;
    }
}
