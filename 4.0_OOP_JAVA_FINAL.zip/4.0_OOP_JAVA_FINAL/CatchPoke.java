import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class CatchPoke {

    public String catchresult;

    public CatchPoke(int rarity) {
        int poke_ball = 1;
        int great_ball = 2;
        int ultra_ball = 3;
        int master_ball = 4;
        int chance = 6;
        Scanner myObj = new Scanner(System.in);
        Random random = new Random();

        while (true) {
            try {
                System.out.println("Which ball: (1) Poke Ball (2) Great Ball (3) Ultra Ball (4) Master Ball (5) Stop");
                int helo = myObj.nextInt();
                if (helo == 1) {
                    int x = random.nextInt(chance + rarity) + poke_ball;
                    if (x == 5) {
                        catchresult = "success";
                        break;
                    } else {
                        System.out.println("Failed. Please try again." + '\n');
                    }
                } else if (helo == 2) {
                    int x = random.nextInt(chance + rarity) + great_ball;
                    if (x == 5) {
                        catchresult = "success";
                        break;
                    } else {
                        System.out.println("Failed. Please try again." + '\n');
                    }
                } else if (helo == 3) {
                    int x = random.nextInt(chance + rarity) + ultra_ball;
                    if (x == 5) {
                        catchresult = "success";
                        break;
                    } else {
                        System.out.println("Failed. Please try again." + '\n');
                    }
                } else if (helo == 4) {
                    int x = random.nextInt(chance + rarity) + master_ball;
                    if (x == 5) {
                        catchresult = "success";
                        break;
                    } else {
                        System.out.println("Failed. Please try again." + '\n');
                    }
                } else if (helo == 5) {
                    catchresult = "fail";
                    break;
                } else {
                    System.out.println("Invalid number, please enter a number between 1 to 5.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid number, please enter a number.");
                myObj.next(); // Clear the invalid input
            }
        }
    }

    public String setcatchresult() {
        return catchresult;
    }
}

