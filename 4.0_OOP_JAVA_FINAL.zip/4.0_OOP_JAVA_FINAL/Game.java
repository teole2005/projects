import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
    import java.util.Scanner;
    public class Game {
        public Game(String playerName) {

            String boldStart = "\033[1m";
            String reset = "\033[0m";
            String playername=playerName;
            Player p=new Player(playername);

            Scanner scanner= new Scanner(System.in);
            ArrayList<PokechoFinal> list = new ArrayList<>();
            ArrayList<PokechoFinal> pokeparty = new ArrayList<>();
            ArrayList<PokechoFinal> pokedetail1 = new ArrayList<>();
            // Thêm phần tử vào ArrayList
            list.add(new PokechoFinal("Pikachu", "Electric", 555, 400,1));
            list.add(new PokechoFinal("Charmander", "Fire", 520, 450,2));
            list.add(new PokechoFinal("Bulbasaur", "Grass", 490, 495,3));
            list.add(new PokechoFinal("Squirtle", "Water", 300, 505,3));
            list.add(new PokechoFinal("Gengar", "Ghost", 590, 450,2));
            Random random = new Random();
            ArrayList<Integer> pokeoptions = new ArrayList<Integer>();
            ArrayList<String> set = new ArrayList<String>();
         
         ArrayList<String> j= p.getAvailablePoke();
         System.out.println(j.size());
         String ifhavepoke="no";
           if (p.getHavePokeInBasementOrNot() =="yes") { if (j.size()>=2) {
        
            System.out.println("There are " + j.size() + " pokémon in your basement." + '\n');
            System.out.println("Choose 2 pokémon for your party." + '\n');
            ArrayList hh=j;
            System.out.format(boldStart + "%-15s%-15s%-15s%-15s%-15s%n" + reset, "NAME", "TYPE", "ATTACK", "DEFENSE", "RARITY");
            for(int idk=0;idk<j.size();idk++){
       
            for(int z=0;z<list.size();z++){
if (hh.get(idk).equals(list.get(z).getName())) {

     
   System.out.format("%-15s%-15s%-15s%-15s%-15s%n", list.get(z).getName(),list.get(z).getType(),list.get(z).getAttack(),list.get(z).getDefense(),list.get(z).getRarity() + '\n'); 
   pokedetail1.add(new PokechoFinal(list.get(z).getName(),list.get(z).getType(),list.get(z).getAttack(),list.get(z).getDefense(),list.get(z).getRarity()));
    break;
}
            }}
            
          while (pokeparty.size() < 2) {
    try {
        System.out.println('\n' + "Please choose a pokémon by entering the sequence:");
        for (int i = 0; i < pokedetail1.size(); i++) {
            System.out.println((i + 1) + ". " + pokedetail1.get(i).getName());
        }

        int pokechoice = scanner.nextInt() - 1;
        if (pokechoice+1>pokedetail1.size()) {
            System.out.println("Invalid number. Please choose a number between 1 and " + pokedetail1.size() + '\n');

        }
        if (pokechoice >= 0 && pokechoice < pokedetail1.size()) {
            System.out.println("You have chosen " + pokedetail1.get(pokechoice).getName());
            pokeparty.add(new PokechoFinal(
                pokedetail1.get(pokechoice).getName(),
                pokedetail1.get(pokechoice).getType(),
                pokedetail1.get(pokechoice).getAttack(),
                pokedetail1.get(pokechoice).getDefense(),
                pokedetail1.get(pokechoice).getRarity()
            ));
            pokedetail1.remove(pokechoice);
        }
      
    } catch (InputMismatchException e) {
        System.out.println("Invalid input. Please enter a number."+ '\n');
        scanner.next(); // Clear the invalid input
    } 
    catch (Exception e) {
        System.out.println("An error occurred: " + e.getMessage()+ '\n');
    }
}
 ifhavepoke="yes";
           }
           }
           if (p.getHavePokeInBasementOrNot()=="no"|| ifhavepoke=="no") {
            System.out.println("You dont have enough pokémon in your basement!" + '\n');
            System.out.println( "We found some wild pokémon! Try to catch it!" + '\n');
            System.out.format(boldStart + "%-15s%-15s%-15s%-15s%-15s%n" + reset, "NAME", "TYPE", "ATTACK", "DEFENSE", "RARITY");
            for ( int i=0;i<3;i++) {
                int x = random.nextInt(list.size());
                pokeoptions.add(x);
                PokechoFinal pokecho = list.get(x);
             
                
System.out.format("%-15s%-15s%-15d%-15d%-15s%n", 
    pokecho.getName(), 
    pokecho.getType(), 
    pokecho.getAttack(), 
    pokecho.getDefense(), 
    pokecho.getRarity()
);
                set.add(pokecho.getName());
        } System.out.println('\n' + "There are 3 pokémon, choose one (1, 2, 3)");
        for (int loop3 = 1; loop3 > 0; loop3++) {
            try {
                if (pokeparty.size() < 2) {
                    System.out.println(set);
                    
                    try {
                        int pokechoice = scanner.nextInt() - 1;
                        
                        if (pokechoice >= 0 && pokechoice < pokeoptions.size()) {
                            System.out.println("You have chosen " + list.get(pokeoptions.get(pokechoice)).getName() + '\n');
                            pokeparty.add(new PokechoFinal(
                                list.get(pokeoptions.get(pokechoice)).getName(),
                                list.get(pokeoptions.get(pokechoice)).getType(),
                                list.get(pokeoptions.get(pokechoice)).getAttack(),
                                list.get(pokeoptions.get(pokechoice)).getDefense(),
                                list.get(pokeoptions.get(pokechoice)).getRarity()
                            ));
                            set.remove(pokechoice);      
                            pokeoptions.remove(pokechoice);
                        } else {
                            System.out.println("Invalid number. Please choose a number between 1 and " + pokeoptions.size()+ '\n');
                        }
                        
                    } catch (InputMismatchException e) {
                        System.out.println("Please enter a valid number."+ '\n');
                        scanner.next(); // Clear the invalid input
                    } catch (IndexOutOfBoundsException e) {
                        System.out.println("Invalid number. Please choose a number between 1 and " + pokeoptions.size()+ '\n');
                    }
                }
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage() + '\n');
            }
        }
        
        }

    int enmypoke=random.nextInt(list.size());
        PokechoFinal b=list.get(enmypoke);
        for (int loop3 = 1; loop3 > 0; loop3++) {
        try {
        System.out.println('\n' + "Ready to join a battle? (1)YES (2)Back to MENU");
        Scanner scanner2= new Scanner(System.in);
        int k=scanner2.nextInt();
        if (k==2) {
            return; 
        }
        if (k==1) {
            System.out.println('\n' + boldStart + "************************** ROUND ONE **************************" + reset + '\n');
            System.out.println(boldStart + "BATTLE START!"+ reset + '\n');
            System.out.println('\n' + "Your enemy is : ");
            System.out.format(boldStart + "%-15s%-15s%-15s%-15s%-15s%n" + reset, "NAME", "TYPE", "ATTACK", "DEFENSE", "RARITY");
            System.out.format("%-15s%-15s%-15d%-15d%-15s%n",b.getName(),b.getType(),b.getAttack(),b.getDefense(),b.getRarity());
            System.out.println('\n' + "Choose a pokémon");
            System.out.println("(1) "+pokeparty.get(0).getName() +" or (2) "+ pokeparty.get(1).getName());
            PokechoFinal a;
        int playerpoke;

            while (true) {
                try {
                    System.out.print("Enter your choice: "+ '\n');
                    int pokechoice = scanner.nextInt();
                    playerpoke = pokechoice - 1;
                    
                    if (playerpoke < 0 || playerpoke >= pokeparty.size()) {
                        throw new IndexOutOfBoundsException("Invalid number. Please choose a valid pokémon."+ '\n');
                    }
    
                    PokechoFinal chosenPokemon = pokeparty.get(playerpoke);
                    a  = chosenPokemon;   
                    break; 
    
                } catch (IndexOutOfBoundsException e) {
                    System.out.println(e.getMessage());
                } catch (Exception e) {
                    System.out.println("Invalid number. Please enter a valid number."+ '\n');
                    scanner.next(); // Clear the invalid input
                }
            }
            System.out.println("You have chosen " + a.getName() + '\n');
            Battle z = new Battle(a,a.getDefense(),b,b.getDefense());

        if (z.getBattleResult()=="won") {
            
        
            p.CalculatePoints(90, "won");
for(int loop4=1;loop4>0;loop4++){
        try {
            System.out.println("- - - - - loading - - - - -" + '\n');
            System.out.println("Would you like to catch "+ b.getName() +"? (1) YES (2) NO");
        Scanner scanner3= new Scanner(System.in);
        int userName=scanner3.nextInt();
            if (userName==1) {
                CatchPoke catchresult=new CatchPoke(b.getRarity());
                if (catchresult.catchresult=="success") {
                   System.out.println('\n' + "You got "+ b.getName() + " !"+ '\n');
                   p.SavePlayerPoke(playername,b.getName());
                }
                if (catchresult.catchresult=="fail") {
               
                }
                break;
            }
            if (userName==2) {
               break;
            }
            else{System.out.println("Please enter a valid input"+ '\n');}
        } 
        catch (InputMismatchException e) {
            System.out.println("Please enter a valid input"+ '\n');
        }
    }  
    
            int enmypokend=random.nextInt(list.size());
                PokechoFinal bnd=list.get(enmypokend);
                System.out.println('\n' + "Found a wild pokémon! ");
                System.out.println('\n' + "Your enemy is : ");
                System.out.format(boldStart + "%-15s%-15s%-15s%-15s%-15s%n" + reset, "NAME", "TYPE", "ATTACK", "DEFENSE", "RARITY");
                System.out.format("%-15s%-15s%-15d%-15d%-15s%n",bnd.getName(),bnd.getType(),bnd.getAttack(),bnd.getDefense(),bnd.getRarity()+ '\n');
                System.out.println('\n' + boldStart + "************************** ROUND TWO **************************" + reset + '\n');
                System.out.println(boldStart + "BATTLE START!"+ reset + '\n');
               Battle z1=new Battle(a,z.getPlayerHp(),b,b.getDefense());
              
                if (z1.getBattleResult()=="won") {
                     p.CalculatePoints(z1.getPlayerHp(), "won");
                    try {
                    System.out.println('\n' + "Would you like to catch "+ bnd.getName() +"? (1) YES (2) NO");
                    Scanner scanner6= new Scanner(System.in);
                    int userName1=scanner6.nextInt();
                    if (userName1==1) {
                        CatchPoke catchresult=new CatchPoke(bnd.getRarity());
                        if (catchresult.catchresult=="success") {
                            System.out.println(boldStart + "You got "+bnd.getName() + " !" + reset + '\n');
                            p.SavePlayerPoke(playername, bnd.getName());
                        }
                        if (catchresult.catchresult=="fail") {
                            System.out.println("pathetic" + '\n');
                        }
                        break;
                        }
                        if (userName1==2) {
                            System.out.println(". . . " + '\n');
                            break;
                        }
                        else{
                            System.out.println("Invalid number"+ '\n');
                        } } catch (InputMismatchException e) {
                            System.out.println("Please enter a valid number."+ '\n');
                        }
                        }
                 if (z1.getBattleResult()=="fail"){
                            pokeparty.remove(playerpoke);
                          
                            p.CalculatePoints(z1.getAIHp(), "fail");
                            System.out.println('\n' + "Found a wild pokémon! ");
                            System.out.println('\n' + "Your next enemy is : ");
                            System.out.format(boldStart + "%-15s%-15s%-15s%-15s%-15s%n" + reset, "NAME", "TYPE", "ATTACK", "DEFENSE", "RARITY");
                            System.out.format("%-15s%-15s%-15d%-15d%-15s%n",pokeparty.get(0).getName(),pokeparty.get(0).getType(),pokeparty.get(0).getAttack(),pokeparty.get(0).getDefense(),pokeparty.get(0).getRarity());
                            System.out.println('\n' + boldStart + "************************** ROUND TWO **************************" + reset + '\n');
                            System.out.println(boldStart + "BATTLE START!"+ reset + '\n');
                            Battle z2=new Battle(pokeparty.get(0),pokeparty.get(0).getDefense(),bnd,z1.getAIHp());
                           if (z2.getBattleResult()=="won") {
                            for(int loop5=1;loop5>0;loop5++){
                            try {
                            p.CalculatePoints(z2.getPlayerHp(), "won");
                            System.out.println('\n' + "Would you like to catch "+ bnd.getName() +"? (1) YES (2) NO");
                            Scanner scanner8= new Scanner(System.in);
                            int userName2=scanner8.nextInt();
                            if (userName2==1) {
                                CatchPoke catchresult=new CatchPoke(bnd.getRarity());
                                if (catchresult.catchresult=="success") {
                                    System.out.println(boldStart + "You got "+bnd.getName() + " !" + reset + '\n');
                                    p.SavePlayerPoke(playername, bnd.getName());
                                }
                                if (catchresult.catchresult=="fail") {
                                    System.out.println("pathetic"+ '\n');
                                }
                                break;
                                }
                                if (userName2==2) {
                                    System.out.println(". . . " + '\n');
                                    break;
                                }
                                else{
                                    System.out.println("Invalid number"+ '\n');
                                } } catch (InputMismatchException e) {
                                    System.out.println("Please enter a valid number"+ '\n');
                                }
                            }
                           }
                           if (z2.getBattleResult()=="fail") {                    
                           }
                           }
           } 
           if (z.getBattleResult()=="fail"){
            pokeparty.remove(playerpoke);
            // System.out.println('\n' + "Found a wild pokémon! ");
            System.out.println('\n' + "Your pokémon is : ");
            System.out.format(boldStart + "%-15s%-15s%-15s%-15s%-15s%n" + reset, "NAME", "TYPE", "ATTACK", "DEFENSE", "RARITY");
            System.out.format("%-15s%-15s%-15d%-15d%-15s%n",pokeparty.get(0).getName(),pokeparty.get(0).getType(),pokeparty.get(0).getAttack(),pokeparty.get(0).getDefense(),pokeparty.get(0).getRarity() + '\n' );
            System.out.println('\n' + boldStart + "************************** ROUND TWO **************************" + reset + '\n');
            System.out.println(boldStart + "BATTLE START!"+ reset + '\n');
            Battle z3=new Battle(pokeparty.get(0),pokeparty.get(0).getDefense(),b,z.getAIHp());
           if (z3.getBattleResult()=="won") {
            p.CalculatePoints(z3.getPlayerHp(), "won");
            for(int loop6=1;loop6>0;loop6++){
          
            try{
            System.out.println('\n' + "Would you like to catch "+ b.getName() +"? (1) YES (2) NO");
            Scanner scanner6= new Scanner(System.in);
            int userName1=scanner6.nextInt();
            if (userName1==1) {
                CatchPoke catchresult=new CatchPoke(b.getRarity());
                if (catchresult.catchresult=="success") {
                    System.out.println(boldStart + "You got "+b.getName() + " !" + reset + '\n');
                    p.SavePlayerPoke(playername, b.getName());
                }
                if (catchresult.catchresult=="fail") {
                    System.out.println("pathetic"+ '\n');
                }
                break;
                }
            if (userName1==2) {
                    System.out.println(". . . " + '\n');
                    break;
                }
            else{
                System.out.println("invail number");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid number." + '\n');
                }
            }
            int enmypokend=random.nextInt(list.size());
                PokechoFinal bnd=list.get(enmypokend);
                System.out.println("Found a new wild pokémon! ");
                System.out.format(boldStart + "%-15s%-15s%-15s%-15s%-15s%n" + reset, "NAME", "TYPE", "ATTACK", "DEFENSE", "RARITY");
                System.out.format("%-15s%-15s%-15d%-15d%-15s%n",bnd,bnd.getType(),bnd.getAttack(),bnd.getDefense(),bnd.getRarity()+ '\n');
                System.out.println('\n' + boldStart + "BATTLE START!"+ reset + '\n');
                Battle z4=new Battle(a,z.getPlayerHp(),bnd,bnd.getDefense());
              
                if (z4.getBattleResult()=="won") {
                    p.CalculatePoints(z4.getPlayerHp(), "won");
                    for(int loop6=1;loop6>0;loop6++){
                    try{
                    System.out.println('\n' + "Would you like to catch "+ bnd.getName() +"? (1) YES (2) NO");
                    Scanner scanner7= new Scanner(System.in);
                    int userName2=scanner7.nextInt();
                    if (userName2==1) {
                        CatchPoke catchresult=new CatchPoke(bnd.getRarity());
                        if (catchresult.catchresult=="success") {
                            System.out.println(boldStart + "You got "+bnd.getName() + " !" + reset + '\n');
                            p.SavePlayerPoke(playername, bnd.getName());
                        }
                        if (catchresult.catchresult=="fail") {
                            System.out.println("pathetic"+ '\n');
                            break;
                        }
                        }
                        if (userName2==2) {
                            System.out.println(". . . " + '\n');
                            break;
                        }
                        else{
                            System.out.println("Invalid number.");
                        } } catch (InputMismatchException e) {
                            System.out.println("Please enter a valid number.");
                        }
                    }
                }
                 if (z4.getBattleResult()=="fail"){
                    p.CalculatePoints(z4.getPlayerHp(), "fail");
                    break;
                 }
                }
           if (z3.getBattleResult()=="fail") {
            p.CalculatePoints( z.getPlayerHp(), "fail");
           }
           }
           break;
        }
        else{System.out.println("Invalid number");}
       
    } 
    catch (InputMismatchException e) {
        System.out.println("Please enter a valid number.");
    }
}
        for (int loop=1;loop>0;loop++){
        System.out.println("Wish to check your point?: (1) YES (2) NO");
        try {
            Scanner scanner9=new Scanner(System.in);
        int w=scanner9.nextInt();
        if (w==1) {
            p.DisplayTopFive(playername);
            break;
        }
        if (w==2) {
            new Main();
            break;
        }
        else{
            System.out.println("Invalid number.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Please enter a valid number.");
    }
        new Main();  
}
        
}
}    
    


    
    

