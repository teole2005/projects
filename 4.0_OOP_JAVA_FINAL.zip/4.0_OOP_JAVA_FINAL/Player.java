import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;


public class Player {
    private String playername;
    private int point;
    private String havepokeinbasementornot="no";
    private ArrayList<String> pokeinbasementname=new ArrayList<>();
    private int LineNumber;
    String boldStart = "\033[1m";
    String reset = "\033[0m";
    
    public Player(String playername) {
        this.playername = playername;
        checkPlayerPoke(playername);
    }

    public String GetPlayerName() {
        return playername;
    }

    public void CalculatePoints(int defLeft, String battleResult) {
        if (defLeft > 0) {
            point = defLeft * 10;
        } else {
            point = 10;
        }
        if (battleResult.equals("WON")) {
            point += 100;
        } else if (battleResult.equals("FAIL")) {
            point += 10;
        }
        SavePoints(playername, point, battleResult);
    }

    public int GetPoint() {
        return point;
    }

    private void SavePoints(String name, int point, String battleResult) {
        String filePath = "hello.txt";
        StringBuilder currentContent = new StringBuilder();
        
        // Read existing content
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                currentContent.append(line).append(System.lineSeparator());
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
        
   
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(currentContent.toString());
            writer.write(name);
            writer.newLine();  
            writer.write(battleResult);
            writer.newLine(); 
            writer.write(String.valueOf(point));  
            writer.newLine(); 
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }



    public void SavePlayerPoke(String playername, String catchpokename) {
         checkPlayerPoke(playername);
        String b=getHavePokeInBasementOrNot();
       if (b=="yes") {
            ArrayList<String> poke = getAvailablePoke();
       
        poke.add(catchpokename);
        try {
            String fileName = "pokename.txt";
            int lineToRemove = getLineNumber(); // Assuming this method returns the line number to remove
            List<String> lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
            if (lineToRemove >= 0 && lineToRemove < lines.size()) {
                lines.remove(lineToRemove);
            }
            StringBuilder newLine = new StringBuilder(playername);
            for(int i=0;i<poke.size();i++){
                newLine.append(" ").append(poke.get(i));
            }
           
            lines.add(newLine.toString());
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                for (String line : lines) {
                    writer.write(line);
                    writer.newLine();
                }
            } catch (IOException e) {
                System.out.println("An error occurred while writing to the file.");
                e.printStackTrace();
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
        }
        if (b=="no") {
   

 String filePath = "pokename.txt";
 
        StringBuilder currentContent = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                currentContent.append(line).append(System.lineSeparator());
            }
        } catch (IOException e) {
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(currentContent.toString());
            writer.write(playername);
            writer.write(" "+catchpokename);
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        }

    }
    public void checkPlayerPoke(String playerName) {
    
        String fileName = "pokename.txt"; // Update to the path of your file
        ArrayList<String> loginName = new ArrayList<>();
        List<List<String>> poke = new ArrayList<>();

        try (Stream<String> stream = Files.lines(Paths.get(fileName), StandardCharsets.UTF_8)) {
            stream.forEach(line -> {
                String[] words = line.split(" ");
                if (words.length > 0) {
                    loginName.add(words[0]);
                }
                List<String> pokeRow = new ArrayList<>();
                for (int i = 1; i < words.length; i++) {
                    pokeRow.add(words[i]);
                }
                poke.add(pokeRow);
            });
            pokeinbasementname=new ArrayList<>();
            for (int i = 0; i < loginName.size(); i++) {
                if (loginName.get(i).equals(playerName)) {
                    LineNumber = i;
                    this.havepokeinbasementornot = "yes";
                    pokeinbasementname.addAll(poke.get(i));
                    break;
                }}
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getLineNumber() {
        return LineNumber;
    }

    public String getHavePokeInBasementOrNot() {
        return havepokeinbasementornot;
    }

    public ArrayList<String> getAvailablePoke() {
        return  pokeinbasementname;
    }



public void DisplayTopFive(String name){
    String fileName = "hello.txt"; // Please change this to the path of your file
    ArrayList<String> loginname = new ArrayList<String>();
    ArrayList<String> battleresult = new ArrayList<String>();
    ArrayList<String> point = new ArrayList<String>();
      ArrayList<Integer> hello = new ArrayList<Integer>();

    try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
        String line;
        int lineNumber = 0;
        while ((line = reader.readLine()) != null) {
            lineNumber++;
            if (lineNumber %3 == 1) {
                    loginname.add(line);
                }
                if (lineNumber % 3== 2) {
                    battleresult.add(line);
                }
                if (lineNumber % 3 == 0) {
                    point.add(line);
                }
            }
           
            for(int i1=0;i1<loginname.size();i1++){
                if (name.equals(loginname.get(i1))) {
                    int a=Integer.valueOf(point.get(i1));
                    hello.add(a);
                }
                }
                for(int loop9=1;loop9>0;loop9++){
                try {
                System.out.println('\n' + "Would you like to check : (1) Top 5 highest point (2) Battle History ");
                Scanner myObj = new Scanner(System.in);  // Create a Scanner object
    
                int userName = myObj.nextInt();
                if (userName==1) {
                    List<Integer> topFive = getTopFiveLargest(hello);
                    System.out.println('\n' + "Top 5 highest point: " + boldStart + topFive + reset);
                    break;
                }
               if (userName==2) {
                for(int i2=0;i2<loginname.size();i2++){
                    if (name.equals(loginname.get(i2))) {
                        System.out.println("");
                        System.out.println("Battle: "+(i2+1));
                        System.out.println("Player: "+ loginname.get(i2));
                        System.out.println("Result: "+ battleresult.get(i2));
                        System.out.println("Score : "+ point.get(i2));
                    }
                   
                    }
                    break;
               }
             else{
                System.out.println("Please enter a valid number." + '\n');
             }
                
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number." + '\n');
            }
        }
    } catch (IOException e) {
        System.err.println("An error occurred while reading the file: " + e.getMessage() + '\n');
    }
 
	}
     public List<Integer> getTopFiveLargest(List<Integer> numbers) {
        // Sort the list in descending order
        Collections.sort(numbers, Collections.reverseOrder());

        // Get the first 5 elements
        return numbers.subList(0, Math.min(5, numbers.size()));
    }




}

