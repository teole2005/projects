import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String boldStart = "\033[1m";
        String reset = "\033[0m";
        Scanner scanner = new Scanner(System.in);
        String TextInBold = "\033[1m\033[20mWELCOME TO Pokémon Ga-Ole Game!\033[0m" + '\n';
        System.out.println(TextInBold);
        System.out.println("What's your name? (please do not include any space)");
        String playerName = scanner.nextLine();
        System.out.println('\n' + "HELLO, " + playerName + " !" );

        while (true) {
            displayMenu();

            try {
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                System.out.println("");

                switch (choice) {
                    case 1:
                    System.out.println(boldStart + "Starting the game..." + reset + '\n');
                        new Game(playerName);
                        break;
                    case 2:
                        new Player(playerName).DisplayTopFive(playerName);
                        break;
                    case 3:
                        // Placeholder for listing available Pokémon
                        System.out.println("Displaying available Pokémon in your basement...");
                      
                        ArrayList<String> availablePokemon = new Player(playerName).getAvailablePoke();
                        System.out.println('\n' + "Pokémon you have: " + boldStart + availablePokemon + reset);
                        break;
                    case 4:
                        System.out.println(boldStart + "Exiting the game. Goodbye!" + reset);
                        scanner.close();
                        return; // Exit the program
                    default:
                        System.out.println("Invalid number. Please choose a valid option.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                scanner.next(); // Clear the invalid input
            }
        }
    }

    private static void displayMenu() {
        String boldStart = "\033[1m";
        String reset = "\033[0m";
        System.out.println(boldStart + "\nMENU:" + reset );
        System.out.println("(1) Start the game");
        System.out.println("(2) Display top 5 points");
        System.out.println("(3) See available Pokémon in your basement");
        System.out.println("(4) Exit");
    }
}

         
