// main.js
console.log(window.sharedData); // Outputs: "Hello from data.js!"
