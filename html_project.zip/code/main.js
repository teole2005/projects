document.addEventListener('DOMContentLoaded', function() {
// justifiheavatar()

    var posts = document.querySelectorAll('.post');
    
    // Loop through each element with the class 'post'
    posts.forEach(function(post) {
        post.onmouseover = function() {
            post.style.animation = "boxshadow 0.5s forwards";
        };

        post.onmouseout = function() {
            post.style.animation = "reverseBoxshadow 0.5s forwards";
        };
    });
});
function readmessage(){
  let message = JSON.parse(localStorage.getItem('message'));
  
if(message!=null){
  console.log(message)
  console.log(message.fun)
  let functionName = `${message.fun}`;
let func = window[functionName] || null;
if (typeof func === "function") {
    func(message.n); // Executes greet("Bob")
    localStorage.removeItem('message');
}
}
}
readmessage()


let showdroplistmenu=false;
let showdroplistcake = false;
let showdroplistcandy = false;
let showdroplisthelp = false;
let showdroplistcart=false
function showdroplist_menu(){
  let doc = document.getElementById("menu-drop-list");
let doc1=document.getElementById('icon-button3')
  console.log(showdroplistcake);

  if (!showdroplistcake) {   
    showdroplistcake = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="gray"
  
  } else {
  
    showdroplistcake = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";

 doc1.style.backgroundColor="white"
    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}

function showdroplist_cake() {
  let doc = document.getElementById("droplist-for-cake");
  let doc1 = document.getElementById("item-cake");
  console.log(showdroplistcake);

  if (!showdroplistcake) {   
    showdroplistcake = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="grey"
  } else {
  
    showdroplistcake = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";
        doc1.style.backgroundColor="white"

    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}



function showdroplist_candy(){
  let doc = document.getElementById("droplist-for-candy");
  let doc1 = document.getElementById("item-candy");
 
  if (!showdroplistcandy) {   
    showdroplistcandy = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="grey"
  } else {
  
    showdroplistcandy = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";
        doc1.style.backgroundColor="white"
        doc.style.display = "none";
    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}
function showdroplist_help(){
  let doc = document.getElementById("droplist-for-help");
  let doc1 = document.getElementById("item-help");
 
  if (!showdroplisthelp) {   
    showdroplisthelp = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="grey"
  } else {
  
    showdroplisthelp = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";
        doc1.style.backgroundColor="white"

    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}
function showdroplist_cart(){
  let doc = document.getElementById("droplist-for-cart");
  let doc1 = document.getElementById("item-cart");
  console.log(showdroplistcart);

  if (!showdroplistcart) {   
    showdroplistcart = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="grey"
  } else {
  
    showdroplistcart = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";
        doc1.style.backgroundColor="white"

    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}
let menu_item={}
function showdroplist_menu_item(number){
let list=document.getElementById("droplist-for-menu"+number)
if(menu_item[number]){
menu_item[number]=false

list.style.display="none"
}else{
  menu_item[number]=true
list.style.display="block"
}
}
let index=1
turnonslide(index)
let timeoutID=null
  function forward(){
    if(timeoutID!=null){
      clearTimeout(timeoutID)
      timeoutID=null
      console.log("hello")
    }
    let slide=document.getElementById("slide")
    slide.style.overflow="hidden"
    let a=document.getElementById("slide"+index)
    // alert("j")
 a.style.animation="toleft 0.5s ease-in forwards"
a.style.zIndex='1'
 index+=1
 if(index>5){
  index=1
}
if(index<1){
index=5
}
 console.log(index)
 turnonslide(index)
      let b=document.getElementById("slide"+index)
       b.style.zIndex="3"
    b.style.animation="tocenterfromright 0.5s ease-out forwards"
   timeoutID= setTimeout(function(){
    addoverflow(index)
   }, 1000);
// setTimeout(function(){console.log("hello")},10000)
  }

  function backward(){

  if(timeoutID!=null){
    clearTimeout(timeoutID)
    timeoutID=null
   console.log(timeoutID)
   console.log("hello")
  }
    let slide=document.getElementById("slide")
    slide.style.overflow="hidden"
   
    let a=document.getElementById("slide"+index)
     
    a.style.animation="toright 0.5s ease-in forwards"
   a.style.zIndex='1'
   
    index-=1
    if(index>5){
     index=1
   }
   if(index<1){
   index=5
   }
    console.log(index)
    turnonslide(index)
         let b=document.getElementById("slide"+index)
          b.style.zIndex="3"
       b.style.animation="tocenterfromleft 0.5s ease-out forwards"
 b.style.overflow="hidden"
       timeoutID= setTimeout(function(){
        addoverflow(index)
       }, 1500);
 
  }
  function addoverflow(index) {
   
    let slide=document.getElementById('slide')
    let b=document.getElementById("slide"+index)
    b.style.overflow = "visible";
    slide.style.overflow="visible"
  
  
}
  function turnonslide(index){
switch (index) {
  case 1:
    slide1()
    break;
 case 2:
    slide2()
    
    break;
  case 3:

    removeslide2()
    slide3()
    break;
 case 4:
   
    removeslide3()
    break;
  default:
    break;
}
  }
  window.addEventListener("load", function() {
  forward()
});

//slide1  
function slide1(){
let isActive=false
let isMoving=false
let isDragging = false;
function movethecookie(event){
  isActive= !isActive
  isMoving=true
  
let mouseX=0
let mouseY=0 
let a=window.scrollY
let b=window.scrollX
function track(event) {
  mouseX = event.clientX
  mouseY = event.clientY
}
  document.addEventListener("mousemove",(event)=>{
    track(event)
  });
  let offsetX = event.clientX -  draggable.offsetLeft;
 let offsetY=event.clientY- draggable.offsetTop
if (isActive){
  console.log(isMoving)
  const draggable = document.getElementById("dragg");
   draggable.style.position=' absolute'
   isDragging = !isDragging;
if(isDragging){
   console.log('hello')
   draggable.style.cursor = "grabbing";
   if(isActive){
     window.addEventListener("scroll",cal)
    window.addEventListener("mousemove",cal) 
  }
}
}
else{
  console.log(x)
  console.log(y)
  const draggable = document.getElementById("dragg");
  draggable.style.position='absolute'

  draggable.style.left =x+'px';
  draggable.style.top =y+'px';
  isActive=false
window.removeEventListener("scroll", cal);
window.removeEventListener("mousemove", cal);
document.removeEventListener("mousemove",track(event) )
}
function cal() {
 if(isActive){
  console.log(isActive)
  draggable.style.left =` ${mouseX - offsetX + window.scrollX-b}px`;
  draggable.style.top = `${mouseY - offsetY + window.scrollY -a}px`;
  x=mouseX-offsetX+window.scrollX-b;
  y=mouseY-offsetY+window.scrollY-a;
 }
}
draggable.addEventListener("dblclick",()=>{

  draggable.style.position='absolute'

  draggable.style.left =0+'px';
  draggable.style.top =0+'px';
  isActive=false
window.removeEventListener("scroll", cal);
window.removeEventListener("mousemove", cal);
document.removeEventListener("mousemove",track(event) )
})
}
const draggable = document.getElementById("dragg");

draggable.addEventListener("click", movethecookie); 
window.addEventListener('mousemove',showCoords)
function showCoords(event) {
    let x = event.clientX;
    let y = event.clientY;
  let location=document.getElementById('location1')
    let axic=location.getBoundingClientRect();
    let y1=axic.top
    let x1=axic.left

let result=math(x,y,x1,y1)

if(result.l>10){ 
 
  document.getElementById("eyesballleft").style.top=result.hoz1+'px'
  document.getElementById("eyesballleft").style.left=result.ver1+'px'
}
if(result.l<=10){
  let x02=x-x1
  let y02=y-y1

document.getElementById("eyesballleft").style.top=y02+'px'
  document.getElementById("eyesballleft").style.left=x02+'px'
}
     let location1=document.getElementById('location2')
    let axic1=location1.getBoundingClientRect();
    let y2=axic1.top
    let x2=axic1.left
    let result1=math(x,y,x2,y2)
    if(result1.l>10){ 
 
      document.getElementById("eyesballright").style.top=result1.hoz1+'px'
      document.getElementById("eyesballright").style.left=result1.ver1+'px'
    }
    if(result1.l<=10){
      let x12=x-x2
      let y12=y-y2

 document.getElementById("eyesballright").style.top=y12+'px'
      document.getElementById("eyesballright").style.left=x12+'px'
    }
  }
function math(x,y,x1,y1){
    let sum1=(x-x1)*(x-x1)
    let sum2=(y-y1)*(y-y1)
    let l=Math.sqrt(sum1+sum2)
    let sin=(y-y1)/l
    let hoz=sin*15
    let cos=(x-x1)/l
    let ver=cos*15
    let ver1=ver*0.5
    let hoz1=hoz*0.5
    return { ver1, hoz1,l }
}
function showRandomMouth() {
    let randomNum = Math.floor(Math.random() * 2) + 1;
    hideAllMouths();
    switch (randomNum) {
        case 1:
            document.getElementById('mouth').style.display = 'block';
            break;
        
        case 2:
            document.getElementById('mouth2').style.display = 'block';
            break;
        default:
            break;
    }
  }
  function hideAllMouths() {
    document.getElementById('mouth').style.display = 'none';
    document.getElementById('mouth1').style.display = 'none';
    document.getElementById('mouth2').style.display = 'none';
    document.getElementById('mouth3').style.display = 'none';
  }
  setInterval(showRandomMouth, 5000);
  document.getElementById("slide1-pic4").addEventListener('click',closeeyes)
  function closeeyes(){
    let eye=document.getElementById('eyesleft')
    let eye1=document.getElementById('eyesright')
    let closeeyes=document.getElementById('eyesleft1')
    let closeeyes1=document.getElementById('eyesright1')
   eye.style.display="none"
   eye1.style.display='none'
   closeeyes.style.display="block"
    closeeyes1.style.display='block'
    hideAllMouths()
    document.getElementById('mouth3').style.display = 'block';
    setTimeout(function(){
      eye.style.display='block'
      eye1.style.display='block'
      closeeyes.style.display="none"
       closeeyes1.style.display="none"
       hideAllMouths()
       document.getElementById('mouth2').style.display = 'block';
    },500)
  }
}
//end slide1

  
//slide2
function slide2(){
  document.getElementById('slide2').addEventListener('mousemove', movelayer);
}

function movelayer(event){
let x=event.clientX
let layer1=document.getElementById("layer1-slide2")
let layer2=document.getElementById("layer2-slide2")
let layer3=document.getElementById("layer3-slide2")
let background=document.getElementById("slide2-background")

layer1.style.left=x*0.03 +'px'
layer2.style.left=x*0.05+'px'
layer3.style.left=x*0.01+'px'
background.style.left=-x*0.005+'px'

}
function removeslide2(){
  document.getElementById('slide2').removeEventListener('mousemove', movelayer);
}
//end slide2

//slide3

function slide3(){

window.addEventListener("mousemove", settime);
window.addEventListener("mouseout", relocalcrossoint);

}
let animationFrameId;
function settime(event) {
  
  cancelAnimationFrame(animationFrameId);  
  movecrossoint(event); 
  animationFrameId = requestAnimationFrame(() => settime(event));
}

function movecrossoint(event) {
  let x = event.clientX;
  let y = event.clientY;

  for (let i = 1; i <= 60; i++) {
    console.log(i)
    let doc = document.getElementById("pic" + i + "-slide3-layer1");
    let doc1 = document.getElementById("oday" + i);
      let x1 = doc1.getBoundingClientRect().left;
      let y1 = doc1.getBoundingClientRect().top;
      let result = math1(x, y, x1, y1); 
      if (result.l < 350) {
        doc.style.top = (-result.ver1 - 160) + "px";
        doc.style.left = (-result.hoz1 - 160) + "px";
      } else {
        doc.style.top = "-160px";
        doc.style.left = "-160px";
      }

  }
}

function relocalcrossoint() {
  for (let i = 1; i <= 60; i++) {
    let doc = document.getElementById("pic" + i + "-slide3-layer1");
      doc.style.top = "-160px";
      doc.style.left = "-160px";
  }
}


function math1(x,y,x1,y1){
  let sum1=(x-x1)*(x-x1)
  let sum2=(y-y1)*(y-y1)
  let l=Math.sqrt(sum1+sum2)
  let sin=(y1-y)/l*(350-l)
  let cos=(x1-x)/l*(350-l)
  let ver1=-sin
  let hoz1=-cos

  return { ver1, hoz1,l }
}
function removeslide3() {
  window.removeEventListener("mousemove", settime);
  window.removeEventListener("mouseout", relocalcrossoint);
  cancelAnimationFrame(animationFrameId); 
  relocalcrossoint(); 
}

//end slide3


let sessionExpanded = {};

function showall(number) {
const container = document.getElementById('container' + number);
const session = container.querySelector('.session');
const bigsession = container.querySelector('.bigsession');
const text=container.querySelector('.text');
  

    // Calculate dynamic heights
    const maxheight = session.offsetHeight;
    const expandedHeight = maxheight + 80; // Expanded container height

    // Initialize transition properties
 
    bigsession.style.transition = "height 0.5s";
    container.style.transition = "height 0.5s";

    // Toggle the expanded/collapsed state for this session
    if (sessionExpanded[number]) {
        // Collapse
     text.innerHTML="Show All"
        bigsession.style.height = '450px';
        container.style.height = '520px';
        sessionExpanded[number] = false;
    } else {
        // Expand
   text.innerHTML="Show Less"
        bigsession.style.height = maxheight + 'px';
        container.style.height = expandedHeight + "px";
        sessionExpanded[number] = true;
    }
}

// Object to keep track of animation state for each button
let buttonindex = {};

function button_animation(number) {
    // Select the button based on the given number
    let button = document.querySelector("#backwardbuttonsession" + number);
    // Select the background element within the button
    let background = button.querySelector('.background-for-button');

    // Check if the animation state for this button is active (true or false)
    if (buttonindex[number]) {
        // If the button is in active state, play the animation normally
        background.style.animation = "button-animation-reverse 0.2s linear forwards";
        console.log('Playing animation for button: ' + number);

        // Toggle the state to false to indicate animation has played
        buttonindex[number] = false;
    } else {
        // Reset animation
        background.style.animation = "none"; // Clear animation
        void background.offsetWidth; // Force reflow to allow re-triggering
        background.style.animation = "button-animation 0.2s linear forwards";
        console.log('Reversing animation for button: ' + number);

        // Toggle the state back to true
        buttonindex[number] = true;
    }
}
function movetolocation(number) {
  let part = document.getElementById("destination" + number);
  let y = part.getBoundingClientRect().top + window.scrollY-70; 
  window.scrollTo({
      top: y,
      behavior: 'smooth'
  });
}

