function showPopup(member) {
    const popup = document.getElementById('popup');
    const img = document.getElementById('popup-img');
    const description = document.getElementById('popup-description');
    description.style.width="500px"

    if (member === 'member1') {
        img.src = 'picture/WhatsApp Image 2024-12-02 at 21.43.02_847d50df.jpg';
        description.innerText = 'This team member is dedicated to designing and developing two key sections of the bakery’s website: Introduction Page and Login/Sign-Up Pages';
    } else if (member === 'member2') {
        img.src = 'picture/z6092882945302_89a173ca784138a54a75d9d7662ea215.jpg';

        description.innerText = 'This team member plays a crucial role in shaping the core functionality and user experience of the bakery’s website. Their responsibilities include: Main Page, Product Details Page, and Cart';
    }
    else if (member === 'member3') {
        img.src = 'picture/WhatsApp Image 2024-12-02 at 21.44.34_8e20a83f.jpg';
        description.innerText = 'is responsible for crafting the Introduction Page and Contact Page of the website, ensuring they are visually appealing, user-friendly, and informative. The Introduction Page highlights the purpose of the website, key features, and an overview of the team or project, offering visitors a clear first impression. ';
    }
    popup.style.display = 'flex';
}

function closePopup() {
    const popup = document.getElementById('popup');
    popup.style.display = 'none';
}