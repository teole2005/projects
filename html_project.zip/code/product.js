  document.getElementById("search").autocomplete="off"

document.addEventListener('DOMContentLoaded', function() {
    // justifiheavatar()
    
        var posts = document.querySelectorAll('.post');
        
        // Loop through each element with the class 'post'
        posts.forEach(function(post) {
            post.onmouseover = function() {
                post.style.animation = "boxshadow 0.5s forwards";
            };
    
            post.onmouseout = function() {
                post.style.animation = "reverseBoxshadow 0.5s forwards";
            };
        });
    });
    

    
    let showdroplistmenu=false;
    let showdroplistcake = false;
let showdroplistcandy = false;
let showdroplisthelp = false;
let showdroplistcart=false

function showdroplist_menu(){
  let doc = document.getElementById("menu-drop-list");
let doc1=document.getElementById('icon-button3')
  console.log(showdroplistcake);

  if (!showdroplistcake) {   
    showdroplistcake = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="gray"
  
  } else {
  
    showdroplistcake = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";

 doc1.style.backgroundColor="white"
    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}

function showdroplist_cake() {
  let doc = document.getElementById("droplist-for-cake");
  let doc1 = document.getElementById("item-cake");
  console.log(showdroplistcake);

  if (!showdroplistcake) {   
    showdroplistcake = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="grey"
  } else {
  
    showdroplistcake = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";
        doc1.style.backgroundColor="white"

    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}



function showdroplist_candy(){
  let doc = document.getElementById("droplist-for-candy");
  let doc1 = document.getElementById("item-candy");
 
  if (!showdroplistcandy) {   
    showdroplistcandy = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="grey"
  } else {
  
    showdroplistcandy = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";
        doc1.style.backgroundColor="white"
        doc.style.display = "none";
    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}
function showdroplist_help(){
  let doc = document.getElementById("droplist-for-help");
  let doc1 = document.getElementById("item-help");
 
  if (!showdroplisthelp) {   
    showdroplisthelp = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="grey"
  } else {
  
    showdroplisthelp = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";
        doc1.style.backgroundColor="white"

    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}
function showdroplist_cart(){
  let doc = document.getElementById("droplist-for-cart");
  let doc1 = document.getElementById("item-cart");
  console.log(showdroplistcart);

  if (!showdroplistcart) {   
    showdroplistcart = true;
    doc.style.display = "block";
    doc.style.animation = "showdroplist 0.5s forwards";
    doc1.style.backgroundColor="grey"
  } else {
  
    showdroplistcart = false;
    doc.style.animation = "showdroplist_revesre 0.1s forwards";
        doc1.style.backgroundColor="white"

    setTimeout(() => {
      doc.style.display = "none";
    }, 100); 
  }
}
let menu_item={}
function showdroplist_menu_item(number){
let list=document.getElementById("droplist-for-menu"+number)
if(menu_item[number]){
menu_item[number]=false

list.style.display="none"
}else{
  menu_item[number]=true
list.style.display="block"
}
}
function setmessage(type,fun,n,date){
  let hello={type: type,fun:fun,n:n,data:date}
  localStorage.setItem("message", JSON.stringify(hello));
}
function movetolocation(n){
  setmessage('onload','movetolocation',n,'none')
  window.location="main.html"
}
function rating(n){
  for(let i=6;i<=10;i++){
          document.getElementById("darkstar"+i).src="picture/star.png"
  }
  for(let i=6;i<=n;i++){
  console.log(i)
      document.getElementById("darkstar"+i).src="picture/star (2).png"
      document.getElementById("darkstar"+i).onclick=function(){
  cancelrating()

      }
        document.getElementById("thankmessage").innerHTML="Thanks For Rating Us"
  }
  document.getElementById("thankmessage").style.display="block"
  }
  function cancelrating(){
      for(let i=6;i<=10;i++){
          document.getElementById("darkstar"+i).src="picture/star.png"
          document.getElementById("darkstar"+i).onclick=function(){
              rating(i)
                  }
  }
  document.getElementById("thankmessage").innerHTML="Canceled your rating"
  }


