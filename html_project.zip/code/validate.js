document.getElementById("contactForm").addEventListener("submit", function (event) {
    event.preventDefault();
    let isValid = true;

    // Clear previous errors
    document.querySelectorAll(".error-message").forEach(msg => msg.style.display = "none");

    // Validate First Name
    const firstName = document.getElementById("firstName").value.trim();
    if (!firstName) {
        showError("firstNameError", "First name is required");
        isValid = false;
    }

    // Validate Last Name
    const lastName = document.getElementById("lastName").value.trim();
    if (!lastName) {
        showError("lastNameError", "Last name is required");
        isValid = false;
    }

    // Validate Area Code
    const areaCode = document.getElementById("areaCode").value.trim();
    if (!areaCode || isNaN(areaCode)) {
        showError("areaCodeError", "Valid area code is required");
        isValid = false;
    }

    // Validate Phone Number
    const phoneNumber = document.getElementById("phoneNumber").value.trim();
    if (!phoneNumber || isNaN(phoneNumber)) {
        showError("phoneNumberError", "Valid phone number is required");
        isValid = false;
    }

    // Validate Email
    const email = document.getElementById("email").value.trim();
    if (!email) {
        showError("emailError", "Email address is required");
        isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showError("emailError", "Enter a valid email address");
        isValid = false;
    }

    // Validate Message
    const message = document.getElementById("message").value.trim();
    if (!message) {
        showError("messageError", "Message is required");
        isValid = false;
    }

    if (isValid) {
        alert("Form submitted successfully!");
        document.getElementById("contactForm").reset();
    }
});

function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    errorElement.textContent = message;
    errorElement.style.display = "block";
}
