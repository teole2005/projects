
const product_data=[
['id0',30,5,10,'Traditional Butter Croissant','Croissant','A traditional butter croissant is a classic French pastry known for its flaky, airy layers and rich, buttery flavor. It’s made from a laminated dough, which involves layering butter between sheets of dough through a process of rolling and folding. '],
['id1',40,6.5,11,'Almond Croissant','Croissant','An almond croissant is a delightful variation of the traditional butter croissant, filled with almond paste and topped with sliced almonds and powdered sugar. The almond filling adds a rich, sweet flavor that pairs beautifully with the flaky, buttery croissant dough.'],
['id2',80,8.5,15,'Cheese Croissant','Croissant','A cheese croissant is a savory variation of the classic buttery croissant, filled with melted cheese. It combines the flaky, airy texture of the croissant with a rich, gooey cheese filling, making it a perfect choice for breakfast or as a snack.'],
['id3',45,7.5,20,'Matcha Croissant','Croissant','A matcha croissant is a unique and modern twist on the traditional French pastry, combining the rich, buttery layers of a croissant with the distinct earthy flavor of matcha (green tea powder). It’s often filled with a matcha-flavored cream or paste and may also have matcha powder sprinkled on top for an added burst of flavor and color.'],
['id4',85,4.5,5,'Chocolate Croissant','Croissant','A chocolate croissant (also known as Pain au Chocolat) is a delicious French pastry made from the same buttery, flaky croissant dough, but filled with rich, melted chocolate. It’s a beloved breakfast or snack option in France and around the world, perfect for those who enjoy the combination of warm, buttery dough and indulgent chocolate'],
['id5',70,3.5,6,'Green Tea Croissant','Croissant','A Green Tea Croissant (sometimes known as a Matcha Croissant) combines the buttery, flaky texture of a traditional French croissant with the earthy, slightly bitter flavor of matcha (green tea powder). The result is a visually striking, delicious pastry that blends the classic croissant with the vibrant taste of green tea.'],

['id6',30,5,10,'Classic Chocolate Layer Cake','Chocolate','A rich, moist chocolate cake with multiple layers, filled and topped with smooth chocolate buttercream. It’s a traditional favorite for birthdays and special occasions.'],
['id7',40,6.5,11,'Chocolate Fudge Cake','Chocolate','A dense and indulgent cake with a gooey, fudge-like texture, often made with extra chocolate or cocoa powder. Topped with a thick fudge frosting for extra decadence.'],
['id8',80,8.5,15,'Molten Lava Cake','Chocolate','Known for its soft outer cake layer and gooey chocolate center, which "flows" when you cut into it. These mini cakes are often served warm with a side of vanilla ice cream.'],
['id9',45,7.5,20,'Flourless Chocolate Cake','Chocolate','Dense, fudgy, and perfect for those avoiding gluten. This cake has an intense chocolate flavor and a texture that’s somewhere between a brownie and a custard.'],
['id10',85,4.5,5,'Chocolate Ganache Cake','Chocolate','A simple, elegant cake layered with or topped by chocolate ganache. The ganache adds a silky, glossy finish and deepens the chocolate flavor, making it a hit for chocolate lovers.'],

['id11',50,5,10,'Fruit Tart','Tart','A classic tart with a buttery pastry crust filled with custard (pastry cream) and topped with fresh fruits like strawberries, kiwis, blueberries, and raspberries. Often glazed with a thin layer of apricot or neutral jelly for shine.'],
['id12',40,6.5,11,'Lemon Tart','Tart','A tangy dessert featuring a shortcrust pastry filled with smooth and zesty lemon curd. Sometimes topped with powdered sugar or a dollop of whipped cream.'],
['id13',80,8.5,15,'Chocolate Tart','Tart','Known for its soft outer cake layer and gooey chocolate center, which "flows" when you cut into it. These mini cakes are often served warm with a side of vanilla ice cream.'],
['id14',40,7.5,20,'Bakewell Tart','Tart','Dense, fudgy, and perfect for those avoiding gluten. This cake has an intense chocolate flavor and a texture that’s somewhere between a brownie and a custard.'],

['id15',30,5,10,'Classic Double-Crust Apple Pie','Apple Pie','A timeless dessert featuring a flaky, golden crust that encases a warm, spiced apple filling. The bottom crust provides a sturdy base, while the top crust—whether solid or lattice—seals in the juices, allowing the flavors to meld as it bakes. '],
['id16',40,6.5,11,'Dutch Apple Pie','Apple Pie','This variation stands out with its crumbly, buttery streusel topping made from flour, sugar, and butter, often enhanced with oats or nuts for extra texture. Beneath the topping is a luscious filling of spiced apples that is sweet yet tangy. '],
['id17',80,8.5,15,'Apple Crumble Pie','Apple Pie','Combining the best of a pie and a crumble, this dessert features a traditional pie crust base filled with spiced apples. Instead of a top crust, it is covered with a buttery crumble topping made from flour, sugar, and butter, often mixed with oats or chopped nuts for added texture. '],
['id18',40,7.5,20,'Caramel Apple Pie','Apple Pie','Caramel Apple Pie is a decadent twist on the traditional apple pie, blending the tartness of apples with the sweetness of creamy caramel. The pie is filled with a mixture of sliced apples, sugar, and warm spices like cinnamon and nutmeg, all enveloped in a gooey caramel sauce. '],

['id19',30,5,10,'Classic Vanilla Marshmallows','Marshmallow','They have a light, airy texture and a mild sweetness, making them perfect for roasting over a campfire, adding to hot cocoa, or enjoying as a snack. Their pillowy softness and melt-in-your-mouth consistency make them a staple in desserts and treats.'],
['id20',40,6.5,11,'Gourmet Flavored Marshmallows','Marshmallow','These artisanal marshmallows come in a variety of unique flavors, such as chocolate, peppermint, strawberry, or toasted coconut. Often made with high-quality ingredients and natural flavorings, they elevate the traditional marshmallow experience. '],

['id21',80,8.5,15,'Classic Hard Candy Lollipops','Lolipop','These are the traditional lollipops made from boiled sugar and flavored with fruity or sweet extracts like cherry, grape, or orange. They have a smooth, glossy texture and are a favorite treat for kids and adults alike.'],
['id22',45,7.5,20,'Swirl Lollipops','Lolipop','Known for their colorful spiral designs, these lollipops combine multiple flavors in a visually appealing way. They are often larger in size and have a fun, playful appearance, making them popular at fairs and candy shops.'],
['id23',80,8.5,15,'Gourmet Lollipops','Lolipop','These upscale lollipops feature unique flavors like salted caramel, espresso, lavender, or champagne. Made with high-quality ingredients, they are often smaller and designed for adults looking for a sophisticated candy experience.'],
['id24',450,7.5,20,'Filled Lollipops','Lolipop','These lollipops have a surprise center, such as bubble gum, chocolate, or a chewy candy. Examples include Tootsie Pops or Blow Pops, which offer an extra layer of fun and flavor.'],
['id25',80,8.5,15,'Sour Lollipops','Lolipop','Packed with tangy flavors like green apple, lemon, or sour cherry, these lollipops have a tart coating that makes them irresistible to those who love a zesty kick.'],
['id26',45,7.5,20,'Organic or Natural Lollipops','Lolipop','Made from organic ingredients and natural flavorings, these lollipops are a healthier alternative. They often feature flavors like mango, pomegranate, or honey, appealing to those who prefer less processed treats.'],
['id27',80,8.5,15,'Character-Shaped Lollipops','Lolipop','Shaped like animals, cartoon characters, or seasonal designs, these lollipops are a hit with kids. They come in a variety of colors and flavors, often sold as novelty items for parties or holidays.'],
['id28',45,7.5,20,'Ice Lollipops (Frozen Lollipops)','Lolipop','These are made by freezing flavored liquids like fruit juice or sweetened water around a stick. Unlike traditional hard candy lollipops, they are cold, refreshing, and perfect for hot weather.']
]

const product_img=[
    ['id0',['img','cach-lam-banh-sung-bo-banh-croissant-ngan-lop-thom-ngon-noi-tieng-cua-phap-202201171412571855.jpg'],['img','6271276c6008b_2303-ev-lescure-13-v1-1.jpeg'],['img','traditional-butter-croissant-suchalis-artisan-bakehouse-110-gm-artisinal-breads-548_grande.webp'],['img','French-Croissants-2363-780x1169.jpg'],['img','64525a1c94b01-bra038357-croissants-poolish-jpg-1041x1395.jpg'],['vid','WhatsApp Video 2024-11-19 at 00.16.23_04977fd5.mp4']],
    ['id1',['img','Almond-Croissant-18.jpg'],['img','Easy-Chocolate-Almond-Croissants-2-crop.webp'],['img','almond-croissant-1.jpg'],['img','Almond-Croissant-21.jpg'],['vid','WhatsApp Video 2024-11-19 at 00.16.23_5d9c3b75.mp4']],
    ['id2',['img','Copy-of-Copy-of-Thefreshmancook-2024-07-07T012034.990.png'],['img','cheese.png'],['img','images (1).png']],
    ['id3',['img','784x1024-teaser-matcha-croissant4.jpg']],
    ['id4',['img','hq720.jpg'],['img','chocolate-croissants-2.jpg'],['vid','Untitled video - Made with Clipchamp.mp4'],['img','Easy-Chocolate-Croissant_IG-3.jpg']],
    ['id5',['img','matcha-green-tea-croissant-with-subtle-matchaflavored-filling_1300781-3993.jpg'],['img','how-to-make-matcha-croissant1.webp']],

    ['id6',['img','2-hersheys-perfectly-chocolate-chocolate-cake-recipe-hero.jpg'],['img','best-chocolate-cake5.jpg'],['img','Chocolate-Covered-Strawberries-Cake-Edited-13-WEB-720x720.jpg']],
    ['id7',['img','vegan-chocolate-fudge-layer-cake.jpg'],['img','Chocolate-fudge-cake-1.png'],['img','choc-caramel-fudge-layer-cake-208457-2.jpg'],['img','Chocolate-fudge-cake-recipe-feature-image-500x375.webp']],
    ['id8',['img','e9b96673-a7df-4f56-9983-de0e244ea2b7.jpg'],['img','Chocolate-Lava-Cake-Feature.jpg'],['img','Chocolate-Lava-Cakes-SQUARE.webp'],['img','Chocolate-Lava-Cakes019-web-square.jpg']],
    ['id9',['img','IMG_9987-flourless-chocolate-cake.jpg'],['img','mini-flourless-chocolate-cakes-1.webp'],['img','Flourless-Chocolate-Orange-Cake_600px.jpg'],['img','flourless-chocolate-cake-self-proclaimed-foodie-3.jpg'],['img','flourless-chocolate-cake-recipe-4158976-hero-01-f1f7afbae45c4c69a47f57916c3b575f.jpg'],['img','Flourless-Chocolate-Cake-Culinary-Hill-1200x800-1.jpg']],
    ['id10',['img','chocolate_marble_mayonnaise_celebration_cake1.webp'],['img','chocolate-cake-32-e1642962398946.webp'],['img','p-belgian-dark-chocolate-ganache-cake-1-kg--271996-m.webp']],
    ['id11',['img','assignment pic/fruit tart1.png'],['img','assignment pic/fruit tart2.png'],['img','assignment pic/fruit tart3.png']],
    ['id12',['img','assignment pic/lemon tart3.png'],['img','assignment pic/lemon tart2.png'],['img','assignment pic/lemon tart1.png']],
    ['id13',['img','assignment pic/chocolate tart2.png'],['img','assignment pic/chocolate tart1.png'],['img','assignment pic/chocolate tart3.png']],
    ['id14',['img','assignment pic/bakewell tart3.png'],['img','assignment pic/bakewell tart2.png'],['img','assignment pic/bakewell tart1.png']],
    ['id15',['img','assignment pic/Classic Double-Crust Apple Pie1.png'],['img','assignment pic/Classic Double-Crust Apple Pie2.png'],['img','assignment pic/Classic Double-Crust Apple Pie3.png']],
    ['id16',['img','assignment pic/Dutch Apple Pie3.png'],['img','assignment pic/Dutch Apple Pie1.png'],['img','assignment pic/Dutch Apple Pie2.png']],
    ['id17',['img','assignment pic/Apple Crumble Pie3.png'],['img','assignment pic/Apple Crumble Pie1.png'],['img','assignment pic/Apple Crumble Pie2.png']],
    ['id18',['img','assignment pic/Caramel Apple Pie3.png'],['img','assignment pic/Caramel Apple Pie1.png'],['img','assignment pic/Caramel Apple Pie2.png']],
    ['id19',['img','assignment pic/Classic Vanilla Marshmallows3.png'],['img','assignment pic/Classic Vanilla Marshmallows.png'],['img','assignment pic/Classic Vanilla Marshmallows2.png']],
    ['id20',['img','assignment pic/Gourmet Flavored Marshmallow3.png'],['img','assignment pic/Gourmet Flavored Marshmallow1.png'],['img','assignment pic/Gourmet Flavored Marshmallow2.png']],
    ['id21',['img','assignment pic/Classic Hard Candy Lollipops1.png'],['img','assignment pic/Classic Hard Candy Lollipops2.png'],['img','assignment pic/Classic Hard Candy Lollipops3.png']],
    ['id22',['img','assignment pic/Swirl Lollipops3.png'],['img','assignment pic/Swirl Lollipops2.png'],['img','assignment pic/Swirl Lollipops1.png']],
    ['id23',['img','assignment pic/Gourmet Lollipops3.png'],['img','assignment pic/Gourmet Lollipops2.png'],['img','assignment pic/Gourmet Lollipops1.png']],
    ['id25',['img','assignment pic/Sour Lollipops1.png'],['img','assignment pic/Sour Lollipops2.png'],['img','assignment pic/Sour Lollipops3.png']],
    ['id26',['img','assignment pic/Organic or Natural Lollipop3.png'],['img','assignment pic/Organic or Natural Lollipop1.png'],['img','assignment pic/Organic or Natural Lollipop2.png']],
    ['id27',['img','assignment pic/character-Shaped Lollipops3.png'],['img','assignment pic/character-Shaped Lollipops2.png'],['img','assignment pic/character-Shaped Lollipops1.png']],
    ['id24',['img','assignment pic/Filled Lollipops3.png'],['img','assignment pic/Filled Lollipops1.png'],['img','assignment pic/Filled Lollipops2.png']],
    ['id28',['img','assignment pic/Ice lollipops3.png'],['img','assignment pic/Ice lollipops2.png'],['img','assignment pic/Ice lollipops1.png']]
   
]


let doc = document.querySelector('footer'); // Lấy phần tử <footer>
let doc1 = doc.querySelectorAll(".footer-li"); // Lấy tất cả các phần tử có class 'footer-li' trong footer

// Kiểm tra nếu danh sách có ít nhất 4 phần tử
if (doc1.length > 3) {
    doc1[3].addEventListener('click', function () {
        window.location = "contact.html"; // Dòng này sẽ điều hướng đến contact.html
      
    });
    doc1[0].addEventListener('click', function () {
        window.location = "members.html"; // Dòng này sẽ điều hướng đến contact.html
      
    });
} else {
    console.log("Không có đủ phần tử .footer-li trong footer");
}
let data = JSON.parse(localStorage.getItem('userdata')) ||null
if(data!=null){
    hidelogin()
}
let element = document.querySelector('.filename'); // Replace '.some-class' with your selector
const filename=element.id

document.getElementById("imgnav").addEventListener('click', function (event) {
    event.preventDefault(); // Prevent default anchor behavior
    window.location.href = "main.html"; // Redirect to main.html
});

function determineType() {

    let types =[ ['Croissant',3],['Chocolate',1],['Tart',2],['Apple Pie',4],['Marshmallow',5],['Lolipop',6]] // Types of products
    let order = [[],[],[],[],[],[]]; // Initialize an object to group orders by type
   for (let i = 0; i < product_data.length; i++) {

            for(let i1=0;i1<types.length;i1++){
                if(product_data[i][5]==types[i1][0]){
                    order[i1].push(i)

                }   
            }
    }

    console.log( order); // Return the categorized orders
    for(let i=0;i<order.length;i++){

for(let i1=0;i1<order[i].length;i1++){
    let container= document.getElementById("container"+types[i][1])
let session=container.querySelector(".session")
    let post=document.getElementById("post1-container1")
    let clone=post.cloneNode(true)
    clone.style.display="block"
    console.log(product_data[order[i][i1]])
    clone.querySelector('.text1').innerHTML=product_data[order[i][i1]][4]
    clone.querySelector('.text2').innerHTML=product_data[order[i][i1]][1]+" RM"
    clone.querySelector('.picpost').src='picture/' + product_img[order[i][i1]][1][1]
    clone.onclick=function(){
        let name=[]
        name=product_data[order[i][i1]][4].split(" ")
        let name1=name.join("_")
        console.log(name1)
        window.location=name1+'.html'
    }
    session.append(clone)
}
    }

}

var quantity = 0
if (filename=="main"){
        determineType()
   
}

if(filename=="cart"){
    cart()
}
if(filename=="contact"){


}
if(filename!='main'&&filename!='cart'&&filename!='contact'){
   slideshow()
    addtext()
    quantity = parseInt(document.getElementById("number").value);
}


function cart(){
    let cart = JSON.parse(localStorage.getItem('cart')) ||null;
    let userdata = JSON.parse(localStorage.getItem('userdata')) ||null;
    let convertedname=[]
    let price=[]
    let total=0
    let user=false
    if(userdata!=null){
user=true
    }else{
        let doc=document.getElementById("containerall")
        let h= doc.querySelector('#here').cloneNode(true)
        h.style.display="flex"
        h.innerHTML=`Please login or sign up `
        doc.append(h)
    }
    if(cart!=null&&user){
        for(let i=0;i<cart.productname.length;i++){
            for(let i1=0;i1<product_data.length;i1++){
                if(cart.productname[i]==product_data[i1][0]){
                    convertedname.push(product_data[i1][4])
                    price.push(product_data[i][1])
                }
            }
            let doc=document.getElementById("containerall")
            let h= doc.querySelector('#here').cloneNode(true)
            h.style.display="flex"
            h.innerHTML=`${i+1}) Name: ${convertedname[i]} quanity: ${cart.productquantity[i]}`
            doc.append(h)
        }
        for(let i=0;i<cart.productquantity.length;i++){
total=total+price[i]*cart.productquantity[i]
        }
        let doc=document.getElementById("containerall")
        let h= doc.querySelector('#here').cloneNode(true)
        h.style.display="flex"
        h.style.fontSize="50px"
        h.innerHTML=`Total: ${total} RM`
        doc.append(h)
        console.log(convertedname)

    }
}

function showrelateresult() {
    let key = document.getElementById("search").value
    let match_result = []; // Initialize an empty array to store matches

    // Create a case-insensitive regular expression from the 'key'
    let regex = new RegExp(key, 'i'); // 'i' flag makes the search case-insensitive
console.log(key)
    // Loop through all product data
    for (let i = 0; i < product_data.length; i++) {
        let text = product_data[i][4]; // Get the 5th element (index 4) in the product data
       if (key==""){

       }
       else{
        if (text.search(regex) !== -1) {
            match_result.push(product_data[i][4]); // Add the entire product to match_result array
        }
       }
     
    }

 
    console.log(match_result);
    if(key!=""){
        let container=document.getElementById('droplist-for-help')
        container.innerHTML=""
        container.style.display="flex"
        let max_result=8
        if(max_result>match_result.length){
            max_result=match_result.length
        }
        console.log(max_result)
        for(let i1=0;i1<max_result;i1++){
            let string=match_result[i1].split(" ")
            let newstring=string.join("_")
            console.log(newstring)
            let partern=document.getElementById("partern")
            let clone=partern.cloneNode(true)
            clone.style.display="flex"
            clone.onclick=function(){
                window.location=newstring+".html"
            }
            clone.innerHTML=match_result[i1]
container.appendChild(clone)

        }
    }
    if(key==""){
           let container=document.getElementById('droplist-for-help')
        container.innerHTML=""
    }
}

function underline(){
    document.getElementById("underline").style.animation="underline 0.5s forwards"
}
function revesreunderline(){
    document.getElementById("underline").style.animation="revesreunderline 0.5s forwards "
}
var elementid=""
window.addEventListener('click',function(){
    elementid = document.activeElement.id;
    console.log(elementid)
    h()
})

function h(){
    let nav = document.getElementsByTagName("nav")[0]; // Access the first <nav> element

    console.log(elementid)
    if(elementid=='search'||elementid=="search-icon"){
        nav.style.minWidth = "400px"; 
        
        
        console.log('jel')
        showrelateresult()
        showthebar()
    }
    else if(elementid!="search"||elementid!="search-icon"){
        revesreunderline()
        revesreshowbar()
        nav.style.minWidth = "1px"; 
        let container=document.getElementById('droplist-for-help')
        container.style.display="none"
        console.log('jel23')
    }
}
function showthebar(){
    let width = window.innerWidth;
    console.log("Viewport width is:", width);
    if(width<500){
        let searchbar=document.getElementById("search-container");
        let icon=document.getElementById("search-icon")
        icon.style.display="none"
        searchbar.style.display="flex"
        searchbar.style.width="200px"
   
      }
    if(width<980&&width>500){
        let searchbar=document.getElementById("search-container");
        let item=document.getElementById("icon-button1-small")
        let icon=document.getElementById("search-icon")
        icon.style.display="none"
        searchbar.style.display="flex"
        searchbar.style.width="200px"
        item.style.display="none"
      }
      if(width>=980){
        let searchbar=document.getElementById("search-container");
        let item=document.getElementById("icon-button1-small")
        let icon=document.getElementById("search-icon")
        icon.style.display="none"
        searchbar.style.display="flex"
        item.style.display="flex"
      }
}
function revesreshowbar(){
    let width = window.innerWidth;
console.log("Viewport width is:", width);
if(width<500){
    let searchbar=document.getElementById("search-container");
    let item=document.getElementById("icon-button1-small")
    let icon=document.getElementById("search-icon")
    icon.style.display="flex"
    searchbar.style.display="none"
    item.style.display="flex"
  }
  if(width<980&&width>500){
    let searchbar=document.getElementById("search-container");
    let item=document.getElementById("icon-button1-small")
    let icon=document.getElementById("search-icon")
    icon.style.display="flex"
    searchbar.style.display="none"
    item.style.display="flex"
  }
  if(width>=980){
    let searchbar=document.getElementById("search-container");
    let item=document.getElementById("icon-button1-small")
    let icon=document.getElementById("search-icon")
    icon.style.display="flex"
    searchbar.style.display="none"
    item.style.display="flex"
  }
}

function addCart() {
    let cart = JSON.parse(localStorage.getItem('cart'))||null;
   
    if (cart!=null) {
        let a=document.getElementById("droplist-for-cart")
        let b=a.querySelector("div")

        let cartcontainer = b;
       b.style.overflow="hidden"

        console.log("helo")
        // Clear the container (optional: to avoid duplicates if this function is called multiple times)
        cartcontainer.innerHTML = "";
cartcontainer.onclick=function(){
    window.location="cart.html"
}

        // Loop through the cart and display products and their quantities
        for (let i = 0; i < cart.productname.length; i++) {
            let p = document.createElement('p');
            let name=""
            for(let i1=0;i1<product_data.length;i1++){
                if(cart.productname[i]==product_data[i1][0])
                {
                    name=product_data[i1][4]
                    console.log(name)
                    console.log('helo')

                }
            }
            p.innerHTML = `${name}, quantity: ${cart.productquantity[i]}`;
            p.style.fontSize="20px"
            p.style.margin="0px"
            cartcontainer.appendChild(p);
        }
    } else {

        let a=document.getElementById("droplist-for-cart")
let b=a.querySelector("p")
b.innerHTML="The cart is empty"
    
    }
  
}



addCart()


let n=1

function addtext(){
    for(let i=0;i<product_data.length;i++){
        if(filename==product_data[i][0]){
            document.getElementById('typename').innerHTML=product_data[i][5]
            document.getElementById('name').innerHTML=product_data[i][4]
            document.getElementById('price').innerHTML="Price: "+product_data[i][1]+" RM"
            document.getElementById('description').innerHTML=product_data[i][6]
            let point=Math.ceil(product_data[i][2]/2)
            for(let i1=1;i1<point&&i1<6;i1++){
                document.getElementById('darkstar'+i1).src="picture/star (1).png"
            }
        }
    }

}
function slideshow(){
    let maxindex=0
    for(let i=0;i<product_img.length;i++){
      if(filename==product_img[i][0]){
        maxindex=product_img[i].length-1
        for(let i1=1;i1<product_img[i].length;i1++){
    if(product_img[i][i1][0]=="img"){
        let parent=document.getElementById("parent")
        let clone=parent.cloneNode(true)
        clone.id="pic"+i1
        console.log(i1)
        clone.src="picture/"+product_img[i][i1][1]
        document.getElementById('mainpic').appendChild(clone)


        let container=document.getElementById('smallpiccontainer')
        let parent1=document.getElementById("smallpic")
        let clone1=parent1.cloneNode(true)
        clone1.id="smallpic"+i1
        clone1.style.display="block"
        clone1.src="picture/"+product_img[i][i1][1] 
        clone1.onclick=function(){
            skiptopic(i1,maxindex)
        }
        container.appendChild(clone1)
    }
    if(product_img[i][i1][0]=="vid"){
        let parent=document.getElementById("parent1")
        let clone=parent.cloneNode(true)
        clone.id="pic"+i1
        console.log(i1)
        clone.querySelector('.vid').src="picture/"+product_img[i][i1][1]
        document.getElementById('mainpic').appendChild(clone)

        let container=document.getElementById('smallpiccontainer')
        let parent1=document.getElementById("smallvid")
        let clone1=parent1.cloneNode(true)
        clone1.id="smallpic"+i1
        clone1.style.display="block"
        clone1.onclick=function(){
            skiptopic(i1,maxindex)
        }
        clone1.querySelector(".vid").src="picture/"+product_img[i][i1][1]
        container.appendChild(clone1)
    }
        }
      }
    }
    

document.getElementById("back").addEventListener('click',function(){
 backwardslide(maxindex)
})
document.getElementById("for").addEventListener('click',function(){
forwardslide(maxindex)
})
          document.getElementById('pic1').style.display="block"
        document.getElementById("smallpic1").style.animation="showborder 1s forwards"
}
function skiptopic(n1,maxindex){
console.log(n)
console.log(n1)
let move=n1-n
if(move>0){
    for(let i=0;i<move;i++){
        forwardslide(maxindex)
    }
}
if(move<0){
    for(let i=0;i<Math.abs(move);i++){
        backwardslide(maxindex)
    }
}
}

function calthedistance(n) {
    // Get the width of the specific small picture
    let heightofsmallpic = document.getElementById("smallpic" + n).offsetHeight;
    n=n-1
    // Get the container element that holds the pictures
    let container = document.getElementById("listpic");
    
    // Calculate the distance to scroll (width of the small picture + 15px margin)
    let distance = n*heightofsmallpic + n*15;
    
    // Scroll the container horizontally by the calculated distance
    container.scrollTo({
        top:distance,
        behavior:'smooth'
    })
    
    // Log the calculated distance for debugging
    console.log(n);
}



function forwardslide(maxindex){

    console.log("smallpic"+n)
        document.getElementById('pic'+n).style.display="none"
        document.getElementById("smallpic"+n).style.animation="revesreshowborder 1s forwards"
    n++
    if(n>maxindex){
        n=1
    }
    calthedistance(n)
    console.log("smallpic"+n)
    document.getElementById("smallpic"+n).style.animation="showborder 1s forwards"
document.getElementById('pic'+n).style.display="block"
console.log(n)
}
function backwardslide(maxindex){

        document.getElementById('pic'+n).style.display="none"
         document.getElementById("smallpic"+n).style.animation="revesreshowborder 1s forwards"
    n=n-1
    if(n<1){
        n=maxindex
    }
    calthedistance(n)
        document.getElementById("smallpic"+n).style.animation="showborder 1s forwards"
document.getElementById('pic'+n).style.display="block"
}
let indexforchangecolor=false
function changecolor(){
if(!indexforchangecolor){
    document.getElementById("background-color-for-addcartbutton").style.animation="bigger 0.75s forwards"
    indexforchangecolor=true
}
else if(indexforchangecolor){
    document.getElementById("background-color-for-addcartbutton").style.animation="reversebigger 0.75s forwards"
    indexforchangecolor=false
}
}

console.log(quantity)
function addquantity() {
  quantity = parseInt(document.getElementById("number").value);
  quantity += 1;
  updateQuantity();
}

function minusquantity() {
  quantity = parseInt(document.getElementById("number").value);
  quantity -= 1;
  if (quantity < 0) {
    quantity = 0; // Prevent negative quantities
  }
  updateQuantity();
}

function updateQuantity() {
  document.getElementById("number").value = quantity;
}

function addtocart() {
  if (quantity === 0) {
    alert("Please enter quantity");
  } else {
    let oldcart = JSON.parse(localStorage.getItem('cart')) ||null;
    let name = [];
    let number= []

    // Loop through oldcart to extract productname from each item
    if(oldcart!=null){
        for (let i = 0; i < oldcart.productname.length; i++) {
            name.push(oldcart.productname[i]);  // Access productname for each item
            number.push(oldcart.productquantity[i])
        }
    }
    
    // Add the new product name
    name.push(filename);
    number.push(quantity)
    console.log(name)
    // Prepare the updated cart object
    const hello = { productname: name, productquantity: number };
    
    // Save the updated cart to localStorage
    localStorage.setItem("cart", JSON.stringify(hello));
    
    alert("Product added to cart!");
    document.getElementById("number").value=0
    addCart()
  }
}


function hidelogin(){
    let data = JSON.parse(localStorage.getItem('userdata')) ||null
console.log(data)
let doc1 = document.querySelectorAll('.menu-item');
let div1 = doc1[3];
let div2 = doc1[4];
div1.innerHTML=data.name;
div2.innerHTML="Log Out";
div2.addEventListener('click',function(event){
    event.preventDefault();
    localStorage.removeItem('message');
    localStorage.removeItem('userdata');
    localStorage.removeItem('cart');
    window.location="login.html"
})
    let doc= document.getElementById("icon-button2")
    let a=doc.querySelectorAll(".item-list2")
    let a1th=a[0]
    let a2th=a[1]
    a1th.innerHTML=data.name;
    a1th.addEventListener('click',function(event){
        event.preventDefault();
    })
    
    a2th.innerHTML="Log Out"
    a2th.addEventListener('click',function(event){
        event.preventDefault();
        localStorage.removeItem('message');
        localStorage.removeItem('userdata');
        localStorage.removeItem('cart');
        window.location="login.html"
    })
}


