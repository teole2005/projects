user_data=[
    ['a@gmail.com','john1','123456'],
    ['b@gmail.com','john2','123456'],
    ['c@gmail.com','john3','123456'],
    ['d@gmail.com','john4','123456'],
]

function checkinforsignup() {

    let repass = document.getElementById("regPassword").value; // Lấy giá trị
    let confirmpass = document.getElementById("regConfirmPassword").value; // Lấy giá trị
  let email=document.getElementById("regEmail").value
  let name=document.getElementById("name").value
  let check=document.getElementById('iAgree').value
  if(repass==''||confirmpass==''||email==''||name==""||check==''){
    hideAllMouths(); // Ẩn tất cả các phần tử
    document.getElementById('mouth1').style.display = 'block';
    if (repass=='') {
       let doc=document.getElementById("name-err-pass")
       doc.innerHTML="Please give the password"
       doc.style.display="block"
  } else{
      doc.style.display="none"
  }
  if (confirmpass=='') {
    let doc=document.getElementById("name-err-repass")
    doc.innerHTML="Please give the confirm password"
    doc.style.display="block"
} else{
   doc.style.display="none"
}
if (email=='') {
    let doc=document.getElementById("name-err-email")
    doc.innerHTML="Please give the email"
    doc.style.display="block"
} else{
   doc.style.display="none"
}
if (name=='') {
    let doc=document.getElementById("name-err-name")
    doc.innerHTML="Please give the name"
    doc.style.display="block"
} else{
   doc.style.display="none"
}
  }
  else{

  }
  
  }
let email="heloo"
let name1='helllo1'
setname(email,name1)
function setname(email,name){
  
    let user={email: email,name:name}
    localStorage.setItem('userData', JSON.stringify(user));
   }
