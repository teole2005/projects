// test.js
window.sharedData = "Hello from data.js!";
  