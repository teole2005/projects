document.addEventListener('DOMContentLoaded', function() {
    // justifiheavatar()
    
        var posts = document.querySelectorAll('.post');
        
        // Loop through each element with the class 'post'
        posts.forEach(function(post) {
            post.onmouseover = function() {
                post.style.animation = "boxshadow 0.5s forwards";
            };
    
            post.onmouseout = function() {
                post.style.animation = "reverseBoxshadow 0.5s forwards";
            };
        });
    });
    

    

    let showdroplistcake = false;
    let showdroplistcandy = false;
    let showdroplisthelp = false;
    function showdroplist_cake() {
      let doc = document.getElementById("droplist-for-cake");
      let doc1 = document.getElementById("item-cake");
      console.log(showdroplistcake);
     
      if (!showdroplistcake) {   
        showdroplistcake = true;
        doc.style.display = "block";
        doc.style.animation = "showdroplist 0.5s forwards";
        doc1.style.backgroundColor="grey"
      } else {
      
        showdroplistcake = false;
        doc.style.animation = "showdroplist_revesre 0.5s forwards";
            doc1.style.backgroundColor="white"
    
        setTimeout(() => {
          doc.style.display = "none";
        }, 500); 
      }
    }
    function showdroplist_candy(){
      let doc = document.getElementById("droplist-for-candy");
      let doc1 = document.getElementById("item-candy");
     
      if (!showdroplistcandy) {   
        showdroplistcandy = true;
        doc.style.display = "block";
        doc.style.animation = "showdroplist 0.5s forwards";
        doc1.style.backgroundColor="grey"
      } else {
      
        showdroplistcandy = false;
        doc.style.animation = "showdroplist_revesre 0.5s forwards";
            doc1.style.backgroundColor="white"
    
        setTimeout(() => {
          doc.style.display = "none";
        }, 500); 
      }
    }
    function showdroplist_help(){
      let doc = document.getElementById("droplist-for-help");
      let doc1 = document.getElementById("item-help");
     
      if (!showdroplisthelp) {   
        showdroplisthelp = true;
        doc.style.display = "block";
        doc.style.animation = "showdroplist 0.5s forwards";
        doc1.style.backgroundColor="grey"
      } else {
      
        showdroplisthelp = false;
        doc.style.animation = "showdroplist_revesre 0.5s forwards";
            doc1.style.backgroundColor="white"
    
        setTimeout(() => {
          doc.style.display = "none";
        }, 500); 
      }
    }