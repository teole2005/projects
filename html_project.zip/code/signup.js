function showCoords(event) {
    let x = event.clientX;
    let y = event.clientY;
  let location=document.getElementById('location1')
    let axic=location.getBoundingClientRect();
    let y1=axic.top
    let x1=axic.left

let result=math(x,y,x1,y1)

if(result.l>10){ 
 
  document.getElementById("eyesballleft").style.top=result.hoz1+'px'
  document.getElementById("eyesballleft").style.left=result.ver1+'px'
}
if(result.l<=10){
  let x02=x-x1
  let y02=y-y1

document.getElementById("eyesballleft").style.top=y02+'px'
  document.getElementById("eyesballleft").style.left=x02+'px'
}
     let location1=document.getElementById('location2')
    let axic1=location1.getBoundingClientRect();
    let y2=axic1.top
    let x2=axic1.left
    let result1=math(x,y,x2,y2)
    if(result1.l>10){ 
 
      document.getElementById("eyesballright").style.top=result1.hoz1+'px'
      document.getElementById("eyesballright").style.left=result1.ver1+'px'
    }
    if(result1.l<=10){
      let x12=x-x2
      let y12=y-y2

 document.getElementById("eyesballright").style.top=y12+'px'
      document.getElementById("eyesballright").style.left=x12+'px'
    }
  }
  
//472 255
function math(x,y,x1,y1){
    let sum1=(x-x1)*(x-x1)
    let sum2=(y-y1)*(y-y1)
    let l=Math.sqrt(sum1+sum2)
    let sin=(y-y1)/l
    let hoz=sin*15
    let cos=(x-x1)/l
    let ver=cos*15
    let ver1=ver*0.5
    let hoz1=hoz*0.5
  
    return { ver1, hoz1,l }
}

function togglePassword() {
    let passwordInput = document.getElementById('regPassword');
    let currentType = passwordInput.type;
    let pic =document.getElementById('pic');
    let pic1 =document.getElementById('pic1');
    if (currentType=="password"){
      passwordInput.type ='text'
  
     pic.style.display='none'
  pic1.style.display='block'
    }
    else{
      passwordInput.type = 'password' 
     pic1.style.display='none'
  pic.style.display='block'
    }
  }

function showRandomMouth() {
  // Tạo số ngẫu nhiên từ 1 đến 3
  let randomNum = Math.floor(Math.random() * 2) + 1;

  // Ẩn tất cả các phần tử
  hideAllMouths();

  // Hiển thị phần tử tương ứng dựa trên số ngẫu nhiên
  switch (randomNum) {
      case 1:
          document.getElementById('mouth').style.display = 'block';
          break;
      
      case 2:
          document.getElementById('mouth2').style.display = 'block';
          break;
      default:
          break;
  }
}

// Hàm để ẩn tất cả các phần tử
function hideAllMouths() {
  document.getElementById('mouth').style.display = 'none';
  document.getElementById('mouth1').style.display = 'none';
  document.getElementById('mouth2').style.display = 'none';
  document.getElementById('mouth3').style.display = 'none';
}

// Thiết lập interval để gọi hàm showRandomMouth mỗi 5000ms
setInterval(showRandomMouth, 5000);



function closeeyes(){

  let eye=document.getElementById('eyesleft')
  let eye1=document.getElementById('eyesright')
  let closeeyes=document.getElementById('eyesleft1')
  let closeeyes1=document.getElementById('eyesright1')
 eye.style.display="none"
 eye1.style.display='none'
 closeeyes.style.display="block"
  closeeyes1.style.display='block'
  hideAllMouths()
  document.getElementById('mouth3').style.display = 'block';
  setTimeout(function(){
    eye.style.display='block'
    eye1.style.display='block'
    closeeyes.style.display="none"
     closeeyes1.style.display="none"
     hideAllMouths()
     document.getElementById('mouth2').style.display = 'block';
  },500)
}
function hello() {
    let passwordInput1 = document.getElementById('regConfirmPassword');
    let currentType1 = passwordInput1.type;
    let pic =document.getElementById('pic2');
    let pic1 =document.getElementById('pic21');
    if (currentType1=="password"){
      passwordInput1.type ='text'
  console.log("DFg")
     pic.style.display='none'
  pic1.style.display='block'
    }
    else{
      passwordInput1.type = 'password' 
     pic1.style.display='none'
  pic.style.display='block'
    }
  }