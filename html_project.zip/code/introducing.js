function showDetails(index) {
  const details = document.querySelectorAll('.team-member .details');
  details[index].style.display = details[index].style.display === 'block' ? 'none' : 'block';
}
