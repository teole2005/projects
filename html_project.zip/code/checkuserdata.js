const user_data=[
    ['u1','e@gmail.com','qwertyuiop','teo'],
    ['u2','e1@gmail.com','123456','dat']
]
function login(){
    let email=document.getElementById("Email").value;
    let pass=document.getElementById("Password").value;

    for(let i=0;i<user_data.length;i++){
        if(email==user_data[i][1]&&pass==user_data[i][2]){
            alert("welcome back "+user_data[i][3])
            let a={id:user_data[i][0],email:user_data[i][1],name:user_data[i][3]}
            localStorage.setItem("userdata", JSON.stringify(a));
            window.location="main.html"
        }
 
        else if(email!=user_data[i][1]&&pass!=user_data[i][2]){
            document.getElementById('name-err-email').innerHTML="incorrect email"
            document.getElementById('name-err-email').style.display="block"
            document.getElementById('name-err-pass').innerHTML="incorrect password"
            document.getElementById('name-err-pass').style.display="block"

        }
        else if(email==user_data[i][1]&&pass!=user_data[i][2]){
            document.getElementById('name-err-email').innerHTML="incorrect email"
            document.getElementById('name-err-email').style.display="block"
            document.getElementById('name-err-pass').innerHTML="incorrect password"
            document.getElementById('name-err-pass').style.display="block"

        }
    }
    if(email==""){
        document.getElementById('name-err-email').innerHTML="please provide email"
       document.getElementById('name-err-email').style.display="block"
}
if(pass==""){
document.getElementById('name-err-pass').innerHTML="please provide password"
document.getElementById('name-err-pass').style.display="block"
}
}
const element = document.getElementById('register_login');

if (element !== null) {
    element.addEventListener('click',login)
} else {
    console.log('Element does not exist!');
}

function signup(event) {
    event.preventDefault();

    let email = document.getElementById("regEmail").value;
    let pass = document.getElementById("regPassword").value;
    let confirmpass = document.getElementById("regConfirmPassword").value;
    let name = document.getElementById("name").value;

    // Reset lỗi
    document.getElementById('name-err-email').style.display = "none";
    document.getElementById('name-err-pass').style.display = "none";
    document.getElementById('name-err-regpass').style.display = "none";
    document.getElementById('name-err-mess').style.display = "none";

    // Kiểm tra các trường bắt buộc
    if (!email) {
        document.getElementById('name-err-email').innerHTML = "Please provide email";
        document.getElementById('name-err-email').style.display = "block";
        return;
    }
    if (!pass) {
        document.getElementById('name-err-pass').innerHTML = "Please provide password";
        document.getElementById('name-err-pass').style.display = "block";
        return;
    }
    if (!confirmpass) {
        document.getElementById('name-err-regpass').innerHTML = "Please provide confirm password";
        document.getElementById('name-err-regpass').style.display = "block";
        return;
    }
    if (!name) {
        document.getElementById('name-err-mess').innerHTML = "Please provide name";
        document.getElementById('name-err-mess').style.display = "block";
        return;
    }
    
    // Kiểm tra email đã tồn tại
    let emailExists = false;
    for (let i = 0; i < user_data.length; i++) {
        if (email === user_data[i][1]) {
            emailExists = true;
            break;
        }
    }

    if (emailExists) {
        document.getElementById('name-err-email').innerHTML = "The email is already used";
        document.getElementById('name-err-email').style.display = "block";
        return;
    }

    // Kiểm tra confirm password
    if (pass !== confirmpass) {
        document.getElementById('name-err-regpass').innerHTML = "The confirm password is incorrect";
        document.getElementById('name-err-regpass').style.display = "block";
        return;
    }
if(pass.length<6){
    document.getElementById('name-err-pass').innerHTML = "Please provide password that longer 6 character";
    document.getElementById('name-err-pass').style.display = "block";
    return;
}
if(name.length>15){
    document.getElementById('name-err-mess').innerHTML = "Please provide name that shorter than 15 character";
    document.getElementById('name-err-mess').style.display = "block";
    return;
  
}
localStorage.clear();

    
    let newUser ={id: 'u' + (user_data.length + 1), email: email, name: name };

  
    localStorage.setItem("userdata", JSON.stringify(newUser));

alert('Welcome '+ name)

    window.location = "introducing.html";
}

// Thêm sự kiện cho form
document.getElementsByTagName('form')[0].addEventListener('submit', signup);



const element1 = document.getElementById('register_signup');

if (element1 !== null) {
    element1.addEventListener('click',signup)
} else {
    console.log('Element does not exist!');
}
