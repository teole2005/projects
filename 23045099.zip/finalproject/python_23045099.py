import time

# Global variables to store data
attendance_data = []
time_table = []
assignments_submissions = []

# Global variable to store the test duration in seconds
ATTENDANCE_DURATION = 900  # 15 minute

# Sample main database containing student and lecturer information
main_database = [
    {"ID": "12340", "password": "leejun", "role": "student", "course_name": "BCNS"},
    {"ID": "12341", "password": "johnlok", "role": "student", "course_name": "SET"},
    {"ID": "12342", "password": "jacklim", "role": "student", "course_name": "SC"},
    {"ID": "12343", "password": "jerry", "role": "student", "course_name": "BCNS"},
    {"ID": "12344", "password": "bobpuah", "role": "student", "course_name": "DA"},
    {"ID": "12345", "password": "evatan", "role": "student", "course_name": "DA"},
    {"ID": "12346", "password": "sarahtoh", "role": "student", "course_name": "AI"},
    {"ID": "12347", "password": "davidbek", "role": "student", "course_name": "SE"},
    {"ID": "12348", "password": "emily", "role": "student", "course_name": "IS"},
    {"ID": "12349", "password": "junhin", "role": "student", "course_name": "IoT"},
    {"ID": "Jane", "password": "abcd", "role": "lecturer", "course_name": "SET"},
    {"ID": "Eileen", "password": "efgh", "role": "lecturer", "course_name": "BCNS"},
    {"ID": "Ahmmad", "password": "ijkl", "role": "lecturer", "course_name": "SC"},
]

## LOGIN PAGE ##
def login():
    while True:
        print("Welcome to Edu Hub!")
        user_id = input("Enter your ID: ")
        password = input("Enter your password: ")

        # Search for the user in the main database
        user = next((record for record in main_database if record["ID"] == user_id and record["password"] == password), None)

        if user:
            if user["role"] == "student":
                print(f"Login successful! Welcome, student. You are enrolled in {user['course_name']}.")
                return "student"
            elif user["role"] == "lecturer":
                print("Login successful! Welcome, lecturer.")
                return "lecturer"
        else:
            print("Incorrect ID or password. Please try again.")

##MAIN_MENU##       
def main_menu(role):
    print("\nMain Menu:")
    print("1. Attendance")
    print("2. Timetable")
    print("3. Assignment Submission")
    print("4. Exit")

    choice = input("Enter your choice: ")

    if choice == '1':
        attendance_menu(role)
    elif choice == '2':
        timetable_menu(time_table, "time_table.txt")
    elif choice == '3':
        assignment_menu()
    elif choice == '4':
        print("Exiting program. Goodbye!")
        exit()
    else:
        print("Invalid input.")
        main_menu(role)

##ATTENDANCE##
def read_attendance_data(file_path):
    try:
        with open(file_path, "r") as file:
            attendance_data = {}
            for line in file:
                parts = line.strip().split(',')
                class_info = parts[0]
                students_info = parts[1:]
                students_attendance = {}
                for student_info in students_info:
                    student, attendance_record = student_info.split(':')
                    students_attendance[student] = [record == 'y' for record in attendance_record.split('|')]
                attendance_data[class_info] = students_attendance
        return attendance_data
    except FileNotFoundError:
        print("Attendance data file not found. Creating new attendance data.")
        return {}

def save_attendance_data(attendance_data, file_path):
    with open(file_path, "w") as file:
        for class_info, students_attendance in attendance_data.items():
            file.write(class_info)
            for student, attendance_record in students_attendance.items():
                file.write(f",{student}:")
                file.write("|".join('y' if record else 'n' for record in attendance_record))
            file.write("\n")      

def mark_attendance(class_info, students, attendance_data, lesson_number):
    print(f"\nMarking attendance for {class_info}, Lesson {lesson_number}:")
    start_time = time.time()  # Record the start time
    end_time = start_time + ATTENDANCE_DURATION  # Calculate end time
    
    # Keep track of students who have already marked attendance
    marked_students = set()

    while time.time() < end_time:
        # Check if there are students left to mark attendance
        remaining_students = [student for student in students if student not in marked_students]
        if not remaining_students:
            print("All students have marked their attendance for this lesson.")
            break
        
        for student in remaining_students:
            while True:
                time_remaining = int(end_time - time.time())
                if time_remaining <= 0:
                    print("Time's up! Attendance marking for Lesson", lesson_number, "is now closed.")
                    save_attendance_data(attendance_data, "attendance_data.txt")  # Save attendance data after marking
                    return
                
                print(f"Time remaining for Lesson {lesson_number}: {time_remaining // 60} minutes {time_remaining % 60} seconds")
                
                status = input(f"Is {student} present for Lesson {lesson_number}? (y/n): ")
                if status in ('y', 'n'):
                    status = status == 'y'
                    marked_students.add(student)  # Add student to marked set
                    break
                else:
                    print("Invalid input. Please enter 'y' for present or 'n' for absent.")
            attendance_data[class_info].setdefault(student, [False] * 10)[lesson_number - 1] = status

def calculate_attendance_percentage(attendance_data, class_info):
    attendance_percentage = {}
    total_lessons = 10  # Total number of lessons in a class
    for student, attendance_record in attendance_data[class_info].items():
        attended_lessons = sum(1 for lesson_attendance in attendance_record if lesson_attendance)
        attendance_percentage[student] = (attended_lessons / total_lessons) * 100
    return attendance_percentage

def display_student_attendance(class_info, attendance_data):
    print(f"\nAttendance for students in {class_info}:")
    for student, attendance_record in attendance_data[class_info].items():
        print(f"{student}:")
        for i, attendance_status in enumerate(attendance_record, start=1):
            lesson_number = f"Lesson {i}"
            status = "Present" if attendance_status else "Absent"
            print(f"\t{lesson_number}: {status}")

##ATTENDANCE_MENU##
def attendance_menu(role):
    attendance_data = read_attendance_data("attendance_data.txt")  # Load attendance data from file
    
    while True:
        print("\nWelcome to the Attendance Management System.")
        print("Choose an option:")
        print("1. Mark Attendance for a class")
        print("2. View Attendance Percentage for all students in a class")
        print("3. View Attendance Percentage for a student in a class")
        print("4. Back to Main Menu")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            print("\nAvailable classes:")
            for i, class_info in enumerate(attendance_data.keys(), start=1):
                print(f"{i}. {class_info}")
            class_index = input("Enter the index of the class for marking attendance: ")

            try:
                class_index = int(class_index)
                if 1 <= class_index <= len(attendance_data):
                    class_to_mark = list(attendance_data.keys())[class_index - 1]
                    print(f"\nSelect a lesson for {class_to_mark}:")
                    for lesson_number in range(1, 11):
                        print(f"{lesson_number}. Lesson {lesson_number}")
                    lesson_number = int(input("Enter the lesson number: "))
                    if 1 <= lesson_number <= 10:
                        mark_attendance(class_to_mark, attendance_data[class_to_mark].keys(), attendance_data, lesson_number)
                    else:
                        print("Invalid lesson number.")
                        continue
                else:
                    print("Invalid input.")
                    continue

            except ValueError:
                print("Invalid input. Please enter a number.")
        
        elif choice == '2':
            print("\nAvailable classes:")
            for i, class_info in enumerate(attendance_data.keys(), start=1):
                print(f"{i}. {class_info}")
            class_index = input("Enter the index of the class to view attendance percentage: ")
            try:
                class_index = int(class_index)
                if 1 <= class_index <= len(attendance_data):
                    class_to_display = list(attendance_data.keys())[class_index - 1]
                    attendance_percentage = calculate_attendance_percentage(attendance_data, class_to_display)
                    print("\nAttendance Percentage for all students in", class_to_display, ":")
                    for student, percentage in attendance_percentage.items():
                        print(f"{student}: {percentage}%")
                else:
                    print("Invalid input.")
            except ValueError:
                print("Invalid input. Please enter a number.")

        elif choice == '3':
            print("\nAvailable classes:")
            for i, class_info in enumerate(attendance_data.keys(), start=1):
                print(f"{i}. {class_info}")
            class_index = input("Enter the index of the class: ")
            try:
                class_index = int(class_index)
                if 1 <= class_index <= len(attendance_data):
                    class_to_display = list(attendance_data.keys())[class_index - 1]
                    display_student_attendance(class_to_display, attendance_data)
                else:
                    print("Invalid input.")
            except ValueError:
                print("Invalid input. Please enter a number.")
        
        elif choice == '4':
            main_menu(role)
        
        elif choice == '5':
            print("Exiting program. Goodbye!")
            exit()

        else:
            print("Invalid input.")
            attendance_menu(role)

##TIMETABLE##
def read_time_table(filename):
    with open(filename, 'r') as time_table:
        timetable = time_table.read().splitlines()
    return timetable


def display(x):
    i = 0
    while i < len(x):
        a = i + 1
        print(f'index: {a} {x[i]}\n')
        i += 1


def delete(x, filename):
    display(x)
    y = int(input('Delete number: '))
    a=y-1
    if a < len(x):
        del x[a]
        with open(filename, 'w') as time_table:
            for entry in x:
                time_table.write(f'{entry}\n')
    else:
        print("Invalid input.")
        return False
    return True


def update(x, filename):
    display(x)
    k = int(input('Update number: '))
    y = k - 1
    if y < len(x):
        z = input("\nEnter class name: ")
        z1 = input("Enter class code: ")
        z2 = input("Enter class lecture\' name: ")
        z3 = input("Enter class room number: ")
        z4 = input("Enter class time slot: ")

        del x[y]

        x.append(f'class name: {z} class code: {z1} lecture\' name: {z2} room number: {z3} time slot: {z4}')

        with open(filename, 'w') as time_table:
            for entry in x:
                time_table.write(f'{entry}\n')
    else:
        print("Invalid input.")
        return False
    return True


def create(x, filename):
    display(x)
    z = input("\nEnter class name: ")
    z1 = input("Enter class code: ")
    z2 = input("Enter class lecture\' name: ")
    z3 = input("Enter class room number: ")
    z4 = input("Enter class time slot: ")

    x.append(f'class name: {z} class code: {z1} lecture\' name: {z2} room number: {z3} time slot: {z4}')

    with open(filename, 'w') as time_table:
        for entry in x:
            time_table.write(f'{entry}\n')

def timetable_menu(x, filename):
    x = read_time_table(filename)

    while True:
        print("\nWelcome to the Timetable System.")
        print("Choose an option:")
        user_choice = input('1. Create Timetable\n2. Update Timetable\n3. Delete Timetable\n4. Display Timetable\n5. Back to main menu\n6. Exit\nEnter your choice: ')
        if user_choice == '1':
            print("\nTime Table Slot:\n")
            create(x, filename)
        elif user_choice == '2':
            print("\nTime Table Slot:\n")
            update(x, filename)
        elif user_choice == '3':
            print("\nTime Table Slot:\n")
            delete(x, filename)
            continue
        elif user_choice == '4':
            print("\nTime Table Slot:\n")
            display(x)
        elif user_choice == '5':
            main_menu(role)
        elif user_choice == '6':
            exit()
        else:
            print("Invalid choice")
            continue
        
        # After each action, ask if the user wants to perform another action or go back to the main menu
        print("\n1. Back to Timetable\n2. Back to Main Menu\n3. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            continue
        elif choice == "2":
            main_menu(role)
        elif choice == "3":
            exit()
        else:
            print("Invalid input.")
            continue


##ASSIGNMENT_SUB##
assignments_submissions = {}

def read_assignments_submissions(filename):
    try:
        with open(filename, 'r') as file:
            # Skip the header row
            next(file)
            for line in file:
                # Split the line into columns
                columns = line.strip().split('\t')
                # Extract information
                student_id, class_info, course, submission_date, submission_status = columns
                # Store assignment submission
                if class_info not in assignments_submissions:
                    assignments_submissions[class_info] = {}
                assignments_submissions[student_id][class_info][course] = (submission_date, submission_status)
        print("Assignment submissions data read successfully.")
    except FileNotFoundError:
        print("Assignment submission data file not found. Creating new assignment submissions data.")
        return {}
    except Exception as e:
        print("Error reading assignment submission data:", e)

# Function to write updated assignment submission data to the file
def write_assignment_submissions(filename):
    try:
        with open(filename, "w") as file:
            file.write("StudentID\tClassName\tCourse\tSubmissionDate\tSubmissionStatus\n")
            for class_info, students in assignments_submissions.items():
                for student_id, submissions in students.items():
                    for course, (submission_date, submission_status) in submissions.items():
                        file.write(f"{student_id}\t{class_info}\t{course}\t{submission_date}\t{submission_status}\n")
        print("Assignment submissions data written to file successfully.")
    except IOError:
        print("Error writing to assignment submission file.")
    except Exception as e:
        print("Error writing assignment submission data:", e)


# Function to submit assignment for a specific course
def submit_assignment(student_id, class_info, course, submission_date, submission_status="Submitted"):
    if class_info not in assignments_submissions:
        assignments_submissions[class_info] = {}
    if student_id not in assignments_submissions[class_info]:
        assignments_submissions[class_info][student_id] = {}
    assignments_submissions[class_info][student_id][course] = (submission_date, submission_status)

# Function to check the status of submitted assignment for a specific student and course
def check_assignment_status(student_id, class_info, course):
    if class_info in assignments_submissions and student_id in assignments_submissions[class_info]:
        if course in assignments_submissions[class_info][student_id]:
            submission_date, submission_status = assignments_submissions[class_info][student_id][course]
            return f"Submitted on: {submission_date}, Status: {submission_status}"
    return "No submission found for the specified student, class, and course."

    
def assignment_menu():
    # Read initial assignment submission data from file
    read_assignments_submissions("assignments_submission.txt")

    while True:
        # Display menu options to the user
        print("\nWelcome to the Assignment Submission System.")
        print("Choose an option:")
        print("1. Submit Assignment")
        print("2. Check Assignment Status")
        print("3. Back to Main Menu")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            # Get input from the user for assignment submission
            student_id = input("Enter your Student ID: ")
            class_info = input("Enter class name: ")
            course = input("Enter the course name: ")
            submission_date = input("Enter the submission date (DD-MM-YYYY): ")
            submit_assignment(student_id, class_info, course, submission_date)
            write_assignment_submissions("assignments_submission.txt")

        elif choice == '2':
            # Get input from the user for checking assignment status
            student_id = input("Enter your Student ID: ")
            class_info = input("Enter class name: ")
            course = input("Enter the course name: ")
            status = check_assignment_status(student_id, class_info, course)
            print("Assignment status:\n", status)

        elif choice == '3':
            # Back to main menu
            main_menu(role)

        elif choice == '4':
            # Exit the program
            print("Exiting the program. Goodbye!")
            exit()

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    role = login()
    main_menu(role)
